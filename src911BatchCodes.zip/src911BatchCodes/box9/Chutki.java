package box9;

public class Chutki {
   
	static int m = 60; //static global var
	       int n = 20; //non-static global var
	 
	static void sing() {  //static method
	  System.out.println("Singing..");
	}
	
	    void cook() {  //non-static method
	    	System.out.println("Ladoo Preparation");
	    }
}
