package box9;

public class Tor {
	
	static int x;
	static double y ;
	static String s;
	
	
  public static void main(String[] args) {
	System.out.println("Main start");
    
	 int a = 60; //local var
	    //local var will not have static nonstatic concept
	 int m ; //var declaration
	  m=30; //initialization (local var must be initialized)
	 System.out.println(m); //30
	  System.out.println("----------------");
	  System.out.println(x); //0
	  System.out.println(y); //0.0
	  System.out.println(s); //null
    System.out.println("Main End");
}
}
