package box9;

public class KGF {

	int a = 90; // non static global var

	void fight() {  //non-static method
		System.out.println("Hammer fight..");
	}

}
