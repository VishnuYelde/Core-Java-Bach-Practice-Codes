package box9;

public class Pushpa {
   public static void main(String[] args) {
	System.out.println("Pushpa Start");
	
//	  int m = new KGF().a;
//	  System.out.println("M value is "+m);
	   System.out.println(new KGF().a);   
	   new KGF().fight();
	   
	   System.out.println("Pushpa End");
}
}
