package box9;

class Tesla
{
   int m = 450; //non-static global var
   
   void drive() { //non-static method
	   System.out.println("Driving Tesla..");
   }
}

public class Baarish {
  public static void main(String[] args) {
	System.out.println("Baarish start");
	
	
	System.out.println(new Tesla().m); //450 //old way
	new Tesla().drive();   //Driving Tesla..  
	
	System.out.println("------------");
	
	Tesla t1 = new Tesla();
	System.out.println(t1.m); //450 //new Fast easy way
	t1.drive(); //Driving Tesla..
	
	System.out.println("--------");
	System.out.println(t1);  //box9.Tesla@6f539caf
	//"ReferenceVariable Contains ADDRESS of an Object" 
	
	System.out.println("Baarish End");	  
}
}
