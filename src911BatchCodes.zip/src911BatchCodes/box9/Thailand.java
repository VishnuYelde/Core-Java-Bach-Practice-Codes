package box9;

class Bangkok{
	
	 static int a = 120;
	 static int z = 555;	
}

public class Thailand {
  
	static int a = 786; // static global variable
	static int b = 300; // static global variable
	       int c = 420; // non-static global variable
	
	       
	  public static void main(String[] args) {
		System.out.println("Main start");	
		    int a = 50;  //local variable
		System.out.println(a); //50
		//local var are given first priority
		System.out.println(Thailand.a); //786
		
		System.out.println(b); //300;
		System.out.println(Thailand.b); //300;
		System.out.println("--------");
		
		System.out.println(new Thailand().c); //420
		
		System.out.println("-------");
		System.out.println(Bangkok.a); //120
		System.out.println(Bangkok.z); //555
	
		System.out.println("Main End");
	}
}
