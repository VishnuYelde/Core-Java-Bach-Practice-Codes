package box9;

class Jadoo{
	
	static int i = 700; //static global var
	       int j = 480; //non-static var
	
	static void power() {   //static method
		System.out.println("Maa Muje Kuch Dekaye Nahi De raha");
	}
	
	       void dhoop() { //non-static method
		System.out.println("Dhooppp..Dhooop..");
	}
}


public class Krish {
   public static void main(String[] args) {
	System.out.println("Krish Start");
	
	System.out.println(Jadoo.i);
	Jadoo.power();
	
	System.out.println(new Jadoo().j);
	new Jadoo().dhoop();
	
	System.out.println("---------------------");
	
	System.out.println(Chutki.m);
	Chutki.sing();
	
	System.out.println(new Chutki().n);
	new Chutki().cook();
	
	System.out.println("Krish End");
}
}
