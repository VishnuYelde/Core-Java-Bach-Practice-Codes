package box1;

import java.util.*;

public class Chitti {
  public static void main(String[] args) {
	  System.out.println("M Start");
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter Gender");
	  char gen = sc.next().charAt(0);
	  
	  System.out.println("Enter age");
	  int age = sc.nextInt();
	  
	  System.out.println("Gender is "+gen);
	  System.out.println("Age is "+age);  //Error
	  
	  System.out.println("M End");
}
}
