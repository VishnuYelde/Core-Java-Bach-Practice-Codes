package box1;

public class Swiggy {
   public static void main(String[] args) {
	
	   char gen = 786;
	   
	   switch(gen)
	   {
	   case 'M','m',65 : System.out.println("Mard..");
	   break;
	   case 'F','f',786 : System.out.println("Stree..");
	   break;
	   case 'O','o': System.out.println("Orry Wale log");
	   break;
	   default: System.out.println("Invalid Gender");
	       
	   }
}
}
