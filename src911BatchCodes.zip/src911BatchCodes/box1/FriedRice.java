package box1;

public class FriedRice {
   public static void main(String[] args) {
	System.out.println("Main start");
	
	  int age = 17;
	  
	  if(age>=18)
	  {
		  System.out.println("Eligeble for Voting");
	  }
	
	System.out.println("Main End");	   
}
}
