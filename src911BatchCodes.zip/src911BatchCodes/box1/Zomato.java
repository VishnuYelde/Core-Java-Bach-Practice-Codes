package box1;

import java.util.Scanner;

public class Zomato {
  public static void main(String[] args) {
	System.out.println("M start");
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter day number");
	  int day = sc.nextInt();
	  
	  switch(day) 
	  {
	  case 1 ,420-> System.out.println("Monday");
	  case 2 ,'A','Z'-> System.out.println("Tuesday"); 
	  case 3 ,786 -> System.out.println("Wednesday");  
	  case 4 -> System.out.println("Thursday"); 
	  case 5 -> System.out.println("Friday");  
	  case 6 -> System.out.println("Saturday"); 
	  case 7 -> System.out.println("Sunday");
	  default -> System.out.println("Invaild Day of Week");
	  }
	  
	  System.out.println("M End");
}
}
