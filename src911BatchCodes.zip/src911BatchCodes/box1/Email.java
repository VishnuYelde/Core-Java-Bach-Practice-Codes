package box1;

public class Email {
  public static void main(String[] args) {
	
	  String mail = "Hemant143Lisa@gmail.com";
	  int pass = 12345;
	  
	  if(mail == "Hemant143Lisa@gmail.com")
	  {
		  if(pass ==12345) {
			  System.out.println("Login Successful");
		  }else {
			  System.out.println("Wrong Password");
		  }
	  }
	  else 
	  {
		  System.out.println("Invalid Email Id");
	  }
}
}
