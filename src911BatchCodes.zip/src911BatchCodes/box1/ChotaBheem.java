package box1;

import java.util.Scanner;

public class ChotaBheem {
  public static void main(String[] args) {
	
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter 1st Num");
	 int a = sc.nextInt();
	 
	 System.out.println("Enter 2nd Num");
	 int b = sc.nextInt();
	 
	 System.out.println("Enter 3rd Num");
	 int c = sc.nextInt();

	 System.out.println("----------");
	 
	 if(a>b && a>c)
	 {
		System.out.println(a+" is Largest"); 
	 }
	 else if (b>a && b>c)
	 {
		 System.out.println(b+" is Largest"); 
	 }else {
		 System.out.println(c+" is Largest"); 
	 }
}
}
