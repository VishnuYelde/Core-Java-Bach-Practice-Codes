package box1;

public class ShantaBai {
  public static void main(String[] args) {
	
	  int a = 35;
	  int b = 70;
	  int c = 90;
	  
	  if(a>b)
	  {
		 if(a>c)
		 {
			System.out.println(a+" is Largest"); 
		 }
		 else
		 {
			 System.out.println(c+" is Largest"); 
		 }
	  }
	  else 
	  {
		 if(b>c) 
		 {
			 System.out.println(b+" is Largest"); 
		 }else {
			 System.out.println(c+" is Largest"); 
		 }
	  }
}
}
