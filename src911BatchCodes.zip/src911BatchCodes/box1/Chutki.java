package box1;

public class Chutki {
  public static void main(String[] args) {
	
	  int age = 22;
	  
	  if(age>=21)
	  {
		  System.out.println("Eligible for Marriage");
	  }
	  else
	  {
		  System.out.println("Have Patience Abhi Tu Bacha Hai");
	  }
}
}
