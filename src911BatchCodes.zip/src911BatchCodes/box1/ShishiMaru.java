package box1;

import java.util.Scanner;

public class ShishiMaru {
  public static void main(String[] args) {
	
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter Your Name");
	  String n = sc.nextLine();
	  
	  System.out.println("Enter your age");
	  int age = sc.nextInt();
	  
	  System.out.println("Enter Gender");
	  char gen = sc.next().charAt(2);
	  
	  System.out.println("Enter Contact Number");
	  long  phno = sc.nextLong();
	  
	  System.out.println("Enter Percentage");
	  double per = sc.nextDouble();
	  
	  System.out.println("-------");
	  System.out.println("Name is "+n);
	  System.out.println("Age is "+age);
	  System.out.println("Gender is "+gen);
	  System.out.println("Conntact Number "+phno);
	  System.out.println("Percentage is "+per);
}
}
