package box1;

public class Biryani {
   public static void main(String[] args) {
	
	   int num = 17;
	   
	   if(num%2 == 0)
	   {
		   System.out.println(num+" is Even");
	   }
	   else 
	   {
		   System.out.println(num+" is Odd");
	   }
}
}
