package box1;

public class ZanduBam {
  public static void main(String[] args) {
	
	  int num = 7;
	  
	  if(num >=0) {
		  System.out.println(num+" is +ve");
	  }else {
		  System.out.println(num+" is -ve");
	  }
}
}
