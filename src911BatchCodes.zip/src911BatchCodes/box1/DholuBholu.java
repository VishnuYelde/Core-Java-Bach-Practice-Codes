package box1;

public class DholuBholu {
  public static void main(String[] args) {
	
	  char gen = 65;
	  
	  if(gen =='M' || gen=='m' ||gen=='A')
	  {
		  System.out.println("Mard..");
	  }
	  else if(gen =='F'|| gen=='f')
	  {
		  System.out.println("Stree.."); 
	  }
	  else if(gen =='O' || gen=='o')
	  {
		  System.out.println("Orry Wale log");
	  }
	  else {
		  System.out.println("Gender Dhek Le Likh");
	  }
}
}
