package box1;

public class Student {
  public static void main(String[] args) {
	
	  char grade = 'C';
	  
	  if(grade == 'A')
	  {
		  System.out.println("Excellent Fantastic result");
	  }
	  else if(grade =='B')
	  {
		  System.out.println("Good result");
	  }
	  else if (grade =='C')
	  {
		  System.out.println("Average ..Ladki pe nahi Padaye Pe Dhayn Do");
	  }
	  else if (grade =='F')
	  {
		  System.out.println("Agle Bar Padaye Kar ke ana");
	  }
	  else {
		  System.out.println("Invalid Grade");
	  }
}
}
