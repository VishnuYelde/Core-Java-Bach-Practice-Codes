package box1;

import java.util.Scanner;

public class Thane {
	
  public static void main(String[] args) {
	System.out.println("Main start");
	
	  Scanner sc = new Scanner(System.in);  //step 2//Scanner Object
	  
	  System.out.println("Enter your name");
	  String s =  sc.next();
	  
	  System.out.println("Enter age");
	  int age = sc.nextInt();
	  
	  System.out.println("---------");
	  System.out.println("Name is "+s);
	  System.out.println("Age is "+age);
	  
	  System.out.println("Main End");
}
}
