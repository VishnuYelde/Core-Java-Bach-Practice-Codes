package box1;

public class Taj {
  public static void main(String[] args) {
	
	  String food = "ButterChicken";
	  
	  if(food == "Samosa")
	  {
		  System.out.println(food +" Price is  450rs");
	  }
	  else if(food =="VadaPav")
	  {
		  System.out.println(food +" Price is  500rs");
	  }
	  else if(food == "Chai")
	  {
		  System.out.println(food +" Price is  500rs");
	  }else {
		  System.out.println("Khana Katham Kal ana");
	  }
}
}
