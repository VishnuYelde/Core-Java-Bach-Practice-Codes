package box26;

public class Yash {
	
	public static int binarySearch(int[] arr , int key) {
		int start = 0;
		int end = arr.length-1;
		
		while(start <= end) {
			int mid = (start+end)/2;
			
			if(arr[mid]==key) {
				return mid;
			}else if(arr[mid]<key) {
				start = mid+1;
			}else if(arr[mid]>key) {
				end = mid-1;
			}
		}		
		return -1;
	}
	
  public static void main(String[] args) {
	
	  int[] ar = {8,12,23,33,46,51,68,79,84,93};
	  int k = 79;
	  
	  int res =  binarySearch(ar, k);
	   
	     if(res != -1) {
	    	 System.out.println(k+" is found in index :"+res);
	     }else {
	    	 System.out.println(k+" doesnot Exist ..");
	     }
}
}
