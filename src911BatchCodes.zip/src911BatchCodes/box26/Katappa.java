package box26;

import java.util.HashMap;
import java.util.Map;

public class Katappa {
  public static void main(String[] args) {
	
	  Map<Integer,String> m1 = new HashMap<Integer,String>();
	  m1.put(500,"Kunal");
	  m1.put(505, "Soham");
	  m1.put(504, "Sandeep");
	  m1.put(503, "Atal");
	  m1.put(501, "Kunal");
	  m1.put(504, "Yash");
	  
	  System.out.println(m1);
	  //{500=Kunal, 501=Kunal, 503=Atal, 504=Yash, 505=Soham}
	  //keys cannot be duplicated
	  //vales can be duplicated
}
}
