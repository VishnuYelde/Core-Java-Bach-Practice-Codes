package box26;

import java.util.Set;
import java.util.TreeMap;

public class RashanCard {
	public static void main(String[] args) {
      
	TreeMap<Integer , Object> t1 = new TreeMap<Integer , Object>();
	t1.put(565, "Apple");
	t1.put(600, true);
	t1.put(550, 350);
	t1.put(120, 55.65);
	t1.put(120, "Sandeep");
	t1.put(230, "Baigan");
	t1.put(420, "Lotus");
	
	System.out.println(t1);

	System.out.println("----------");
	
	Set<Integer> s1 = t1.keySet() ;
	
	for(Integer i : s1) {
		System.out.println(i+" --> "+t1.get(i));
	}
	
	}
}
