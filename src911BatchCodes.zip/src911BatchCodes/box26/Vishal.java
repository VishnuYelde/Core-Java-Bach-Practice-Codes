package box26;

public class Vishal {
	
	public static int linearSearch(int[] arr, int key) {
		
		for(int i=0; i<arr.length; i++ ) {
			if(arr[i]==key) {
				return i;
			}
		}	
		return -1;
	}
	
   public static void main(String[] args) {	
	   int[] ar = {45,18,69,23,28,56,91,98};
	   int k = 77;
	 	 
	     int res =  linearSearch(ar, k);
	   
	     if(res != -1) {
	    	 System.out.println(k+" is found in index :"+res);
	     }else {
	    	 System.out.println("Key doesnot Exist ..");
	     }
   }
}
