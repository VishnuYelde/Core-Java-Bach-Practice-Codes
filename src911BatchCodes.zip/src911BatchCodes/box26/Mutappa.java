package box26;

import java.util.HashMap;
import java.util.Map;

public class Mutappa {
  public static void main(String[] args) {
	
	  Map<Integer,Object> m1 = new HashMap<Integer,Object>();
	  m1.put(700, "Atal");
	  m1.put(850, 77.654);
	  m1.put(760, true);
	  m1.put(500, "Mango");
	  m1.put(300, "Rose");
	  m1.put(300, "SonChafa");
	  m1.put(350, "Bhendi");
	  
	  System.out.println(m1);
	  //{850=77.654, 500=Mango, 760=true, 700=Atal, 300=SonChafa, 350=Bhendi}
	  
	  m1.put(100, "Mango");
	  System.out.println(m1);
	  //{850=77.654, 500=Mango, 100=Mango, 760=true, 700=Atal, 300=SonChafa, 350=Bhendi}
}
}
