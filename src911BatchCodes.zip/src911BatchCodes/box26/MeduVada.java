package box26;

import java.util.LinkedHashMap;
import java.util.Map;

public class MeduVada {
  public static void main(String[] args) {
	
	  Map<Object,Object> m1  =new LinkedHashMap<Object,Object>();
	  m1.put("Yash", 786);
	  m1.put(50, true);
	  m1.put(66.66, "Kiwi");
	  m1.put(null, 420);
	  
	  System.out.println(m1);
	  
	  System.out.println(m1.containsKey("Yash")); //true
	  System.out.println(m1.containsKey(50)); //true
	  System.out.println(m1.containsKey("Kiwi")); //false
	  System.out.println("-------");
	  System.out.println(m1.get(66.66)); //Kiwi
	  System.out.println(m1.get(50)); //true
	  System.out.println(m1.get("Yash")); //786
	  System.out.println("------------");
	  System.out.println(m1.containsValue(420)); //true
	  System.out.println(m1.containsValue(66.66)); //false
	  System.out.println(m1.containsValue("Yash")); //false
	  
	  System.out.println("------------");
	  System.out.println(m1.size()); //4 entries
	  
	  System.out.println(m1.isEmpty()); //false
	  
	  m1.remove(null);  //key inside remove method
	  m1.remove("Yash");
	  System.out.println(m1); //{50=true, 66.66=Kiwi}
	  System.out.println("-----------");
	  m1.clear();
	  System.out.println(m1); //{}
	  
	  System.out.println(m1.isEmpty()); //true
	
}
}
