package box25;

import java.util.LinkedHashSet;

public class Raaz {
  public static void main(String[] args) {
	
	  LinkedHashSet<Object> l1 = new LinkedHashSet<Object>();
	  l1.add("bhindi");
	  l1.add("Gawar");
	  l1.add("safarchand");
	  l1.add("Kalingad");
	  l1.add("Kalingad");
	  l1.add(600);
	  l1.add(true);
	  l1.add("Aamba");
	  l1.add("Ananas");
	  l1.add("Fanas");
	  l1.add("Keli");
	  l1.add("Keli");
	  l1.add("Kalingad");
	  
	  System.out.println(l1);
	  //[bhindi, Gawar, safarchand, Kalingad, 600, true, Aamba, Ananas, Fanas, Keli]
	  
}
}
