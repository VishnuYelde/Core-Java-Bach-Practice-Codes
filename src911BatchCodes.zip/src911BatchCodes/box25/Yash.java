package box25;

import java.util.Collections;
import java.util.HashSet;

public class Yash {
  public static void main(String[] args) {
	
	  HashSet<Integer> s1 = new HashSet<Integer>();
	  s1.add(25);
	  s1.add(5);
	  s1.add(35);
	  s1.add(95);
	  s1.add(50);
	  s1.add(50);
	  s1.add(50);
	  s1.add(50);
	  s1.add(20);
	  s1.add(64);
	  s1.add(78);
	  
	  System.out.println(s1);
	  //[64, 50, 35, 20, 5, 25, 78, 95]
	  
	
	  
	  
	  
}
}
