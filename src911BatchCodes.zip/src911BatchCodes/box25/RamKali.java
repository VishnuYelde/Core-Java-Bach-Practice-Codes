package box25;

import java.util.TreeSet;

public class RamKali {
  public static void main(String[] args) {
	
	  TreeSet<String> t1 = new  TreeSet<String>();
	  t1.add("Prajwal");
	  t1.add("Prashant");
	  t1.add("Yash RG");
	  t1.add("Rahul");
	  t1.add("Akshat");
	  t1.add("Yash RH");
	  t1.add("Akshat");
	  t1.add("Mayur");
	  t1.add("Bhavik");
	  t1.add("Chetan");
	  t1.add("Abhishek");
	  t1.add("Abhay");
	  t1.add("Abhay");
	  t1.add("Abhay");
	  t1.add("Abhay");
	  t1.add("Sahil");
	  
	  System.out.println(t1);
	  
	  int i = 1;
	  
	  for(String s : t1) {
		System.out.println(i+" --> "+s);  
		i++;
	  }
	  
}
}
