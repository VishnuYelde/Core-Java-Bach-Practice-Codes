package box25;

import java.util.*;

public class Idli {
  public static void main(String[] args) {
	                //Upcasting , generalization
	  List<Object> l1 = new ArrayList<Object>();
	  l1.add("Hritik");
	  l1.add(600);
	  l1.add(true);
	  l1.add(55.55);
	  
	  System.out.println(l1);
	  Set<Object> s1  = new HashSet<Object>();
	  
}
}
