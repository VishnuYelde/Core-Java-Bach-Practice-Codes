package box25;

import java.util.*;

public class Sambar {
  public static void main(String[] args) {
	
	  Set<Object> s1  = new HashSet<Object>();
	  s1.add("Akshat");
	  s1.add("Simran");
	  s1.add(700);
	  s1.add(700);
	  s1.add(700);
	  s1.add(700);
	  s1.add("Simran");
	  s1.add("Vishal");
	  s1.add("Viraj");
	  s1.add("VediKa");
	  s1.add("Atal");
	  s1.add("Khushi");
	  s1.add("Chetan");
	  s1.add("Swara");
	  s1.add(null);
	  
	  System.out.println(s1); 
	//  [null, Atal, Simran, Viraj, VediKa, Swara, Akshat, Khushi, 700, Chetan, Vishal]
	  //duplicates are not allowed
	  //insertion order is not maintained
}
}
