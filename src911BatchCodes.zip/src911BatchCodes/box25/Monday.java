package box25;

import java.util.TreeSet;

public class Monday {
  public static void main(String[] args) {
	
     TreeSet<Integer> t1 = new TreeSet<Integer>();
     t1.add(65);
     t1.add(75);
     t1.add(80);
     t1.add(95);
     t1.add(95);
     t1.add(70);
     t1.add(40);
     t1.add(45);
     t1.add(30);
     t1.add(30);
     t1.add(10);
     t1.add(20);
     t1.add(15);
     
     System.out.println(t1);
     //[10, 15, 20, 30, 40, 45, 65, 70, 75, 80, 95]
     
     
}
}
