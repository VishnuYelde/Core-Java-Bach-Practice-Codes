package box25;

import java.util.TreeSet;

public class Bakasur {
  public static void main(String[] args) {
	
	  TreeSet<Character> t1 = new TreeSet<Character>();
	  t1.add('M');
	  t1.add('R');
	  t1.add('P');
	  t1.add('D');
	  t1.add('D');
	  t1.add('A');
	  t1.add('A');
	  t1.add('Z');
	  t1.add('H');
	  t1.add('X');
	  
	  System.out.println(t1); 
	  //[A, D, H, M, P, R, X, Z]
}
}
