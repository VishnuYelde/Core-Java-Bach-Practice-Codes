package box25;

import java.util.Collections;
import java.util.Iterator;
import java.util.Vector;

public class Birthday {
   public static void main(String[] args) {
	System.out.println("Main start");
	
	Vector<Integer> v1 = new Vector<Integer>();
	v1.add(60);
	v1.add(10);
	v1.add(45);
	v1.add(90);
	v1.add(79);
	v1.add(18);
	v1.add(22);
	v1.add(50);
	
	System.out.println(v1); //[60, 10, 45, 90, 79, 18, 22, 50]
	
	Collections.sort(v1);
	
	System.out.println(v1); //[10, 18, 22, 45, 50, 60, 79, 90]
	//sorted in acsending order
	System.out.println("------");
	for(Integer i : v1) {
		System.out.println(i);
	}
	
	System.out.println("------");
	
	Collections.reverse(v1);
	System.out.println(v1); //[90, 79, 60, 50, 45, 22, 18, 10]
	
                      //	v1.add(2,null);
	Iterator i1 = v1.iterator();
	
	while(i1.hasNext()) {
		System.out.println(i1.next());
	}
	
	System.out.println("Main End");
}
}
