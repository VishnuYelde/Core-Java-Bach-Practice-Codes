package box25;

import java.util.Stack;

public class Fatafat {
  public static void main(String[] args) {
	
	  Stack<Object> s1 = new Stack<Object>(); 
	  s1.add("Rancho");
	  s1.push("Mona");
	  s1.push(500);
	  s1.push(true);
	  s1.push("Sandeep");
	  
	  System.out.println(s1);
	  
	  System.out.println(s1.peek()); //Sandeep
	  //peek() is used to see the next upcoming element
	  
	  System.out.println(s1.pop()); //Sandeep
	  //pop() will remove the top element
	  
	  System.out.println(s1);
	      //[Rancho, Mona, 500, true]
	  
	  System.out.println(s1.search("Mona")); //3
	  System.out.println(s1.search(true)); //1
	  System.out.println(s1.search(500)); //2
	  System.out.println(s1.search(900)); //-1  //element doesn't Exist     
	  
	  System.out.println(s1.isEmpty()); //false
	  s1.clear();
	  System.out.println(s1); //[]
	  System.out.println(s1.isEmpty()); //true
}
}
