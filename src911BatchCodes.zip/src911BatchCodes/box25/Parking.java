package box25;

import java.util.TreeSet;

public class Parking {
  public static void main(String[] args) {
	
	  TreeSet<Integer> t1 = new TreeSet<Integer>();
	  t1.add(60);
	  t1.add(40);
	  t1.add(50);
	  t1.add(90);
	  t1.add(90);
	  t1.add(20);
	  t1.add(10);
	  t1.add(70);
	  t1.add(95);
	  
	  System.out.println(t1); //Natural sorting order
	  //[10, 20, 40, 50, 60, 70, 90, 95]	  
}
}
