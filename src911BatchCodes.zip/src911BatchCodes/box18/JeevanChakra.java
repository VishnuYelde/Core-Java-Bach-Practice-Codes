package box18;


/*2Rule) When a class inherits an abstract class ,and we don't want to override the 
inherited abstract method ,then make the subclass as abstract class 
*/
abstract class Swarg{  //abstract class
	
	abstract  void rambha();  //abstract methods
	abstract void urvashi();
	abstract void menka();
	
	void narad() {   //concrete method
		System.out.println("Narayaan Narayaan..");
	}
}

abstract class Indra extends Swarg{

	@Override
	void rambha() {
	System.out.println("Jingalala...");
	}

	@Override
	void menka() {
		System.out.println("Lavni Dance...");
	}
	
}

class Ashish extends Indra{

	@Override
	void urvashi() {
	  System.out.println("Chandra song dance with Ashish");
	}
	
}

public class JeevanChakra {
  public static void main(String[] args) {
	
	  Swarg s1 = new Ashish();  //Upcasting
	  s1.rambha();
	  s1.urvashi();
	  s1.menka();
	  s1.narad();
	  
	  
}
}
