package box18;

interface Himanshu{   //interface
	public abstract void love();
	              void party();
}

interface Dheeraj{    //interface
	public abstract void love();
	               void party();
}

interface Sahil {    //interface
	public abstract void party();
}

class Atal {   //concrete class
	 void ghar() {
		System.out.println("Bada Ghar");
	}
}

/*A class can  implement any number of interfaces 
(multiple inheritance) 
 
A class can extend 1 class and implement 
any number of interfaces 
*/

class Riya extends Atal implements Himanshu, Dheeraj, Sahil{

	@Override
	public void love() {
		System.out.println("Riya Controlling everyones love");
	}
	

	@Override
	public void party() {
		System.out.println("All Party Managed by Riya");
	}
	
}

public class BirthdayParty {
public static void main(String[] args) {
	
	Dheeraj d1 = new Riya();  //Upcasting
	d1.party();
	d1.love();
	
	System.out.println("-------");
	
	Himanshu h1 = new Riya(); //Upcasting
	h1.party();
	h1.love();

	System.out.println("-------");
	Riya r1 = new Riya();
	r1.ghar();
	
}
}
