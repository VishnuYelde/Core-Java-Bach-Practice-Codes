package box18;

public interface PatalLok {
  
	public static final int a = 40;
	                    int age =21; 
	 //variables are automatically  public static final
	
	public abstract void jump() ; //abstract method
	
	//we cannot write concrete methods inside interface
//	void dance() {  
//		System.out.println("Lavani");
//	}
}
