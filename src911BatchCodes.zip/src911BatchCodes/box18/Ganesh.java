package box18;

interface Mushak{
	
	void ride(); 
	//by default methods are public and abstract
}

class Bappa implements Mushak{

	@Override
	public void ride() {
		System.out.println("Maze se riding..");
	}
	/*while overriding the method, access specifier should 
be same or of higher visibility 
ex: Public ----to public is Correct 
public ------protected ,default ,private is Wrong 
*/
}

public class Ganesh {
  public static void main(String[] args) {
	
	  Bappa b1 = new Bappa();
	  b1.ride();
}
}
