package box18;

abstract class Kanchana{ //abstract class
	
	void revenge() {  //concrete method
		System.out.println("Chaku Se Marna");
	}
	
	abstract void skip(); //abstract method
}

class Munjya{  //concrete class
	
	void jump() { //concrete method
		System.out.println("Jumping..");		
	}
	
	//abstract void dance(); 
	//we cannot write abstract method in concrete class
}


public class Marco {
  public static void main(String[] args) {
    
	  Munjya m1 = new  Munjya();  //Object
	  
	  //Kanchana k1 = new Kanchana();  //we cannot create Objects of Abstract class
}
}
