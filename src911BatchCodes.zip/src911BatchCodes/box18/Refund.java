package box18;

interface Amazon{
	
//	Amazon(){  //we cannot write constructors in interface
//	  System.out.println("Inside Constructor");
//	}
	
	public static final int p = 420; 
	                    int q = 786;
	
	 void replace(); //abstract method                   
	
	 //main method is allowed in interface
	//which means static concrete methods are allowed in interface
	static void delivery()   //static concrete method
	 {  
		 System.out.println("COD");
	 }
	
	 //non-static concrete methods are not allowed in interface	
//	void swim() { 
//	 System.out.println("Swimming");
//	}
}

public class Refund {
    public static void main(String[] args) {
		System.out.println(Amazon.p);
		System.out.println(Amazon.q);
		//accessing static variable
		
		Amazon.delivery();
		
	}
}
