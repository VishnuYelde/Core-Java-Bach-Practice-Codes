package box13Enc;

class Dheraj
{
	void love() {
		
	}
}

class Himanshu{
     void love() {
		
	}
	
	void party() {
		System.out.println("ITC narmada..");
	}
}

class Riya extends Dheraj{
	
}


public class BirthdayParty {
   public static void main(String[] args) {
	
}
}
