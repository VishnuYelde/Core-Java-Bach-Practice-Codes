package box13Enc;

class Papa
{
	void house() {
		System.out.println("Big Building..");
	}	
}

class Son  extends Papa{
	
	void nashedi() {
		System.out.println("Ganja Ganja..");
	}
}

class Daughter extends Papa{
	
	void reels() {
	  System.out.println("shaky shaky..");
	}
}


public class Crimepetrol {
  public static void main(String[] args) {
	System.out.println("Crime start");
	
	Son s1 = new Son();
	s1.house();
	s1.nashedi();
	   //s1.reels(); //CTE
	System.out.println("----------");
	
	Daughter  d1 = new Daughter ();
	d1.house();
	  //d1.nashedi(); //CTE
	d1.reels();
	
	System.out.println("Crime End");
}
}
