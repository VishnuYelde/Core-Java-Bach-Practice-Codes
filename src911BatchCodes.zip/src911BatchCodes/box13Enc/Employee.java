package box13Enc;

public class Employee { //step 1 public class
    
	private String name; //step 2 private variables
	private int empid;
	private double sal;
	
	//public constructor //step 3
	public Employee(String name, int empid, double sal) {
		this.name = name;
		this.empid = empid;
		this.sal = sal;
	}

	//step 4 Public getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public double getSal() {
		return sal;
	}

	public void setSal(double sal) {
		this.sal = sal;
	}
		
}






