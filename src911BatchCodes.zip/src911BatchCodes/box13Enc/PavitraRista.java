package box13Enc;

class Granny{
	
	void pyaar() {
		System.out.println("Dadi ka Pyaar..");
	}
	
}

class Mom extends Granny{
	
	void care() {
		System.out.println("Caring...");
	}
	
}

class Beti extends Mom {
	
	void kalesh() {
		System.out.println("karcha karna...");
	}
}

public class PavitraRista {
 public static void main(String[] args) {
	System.out.println("Rista start");
	
	Beti b1 = new Beti();
	b1.pyaar();
	b1.care();
	b1.kalesh();
	System.out.println("---------");
	
	Mom m1 = new Mom();
	m1.pyaar();
	m1.care();
	   //m1.kalesh(); //CTE
	
	System.out.println("---------");
	
	Granny g1 = new Granny();
	g1.pyaar();
	//g1.care();  //CTE
	//g1.kalesh();  //CTE
	 
	
	System.out.println("Rista End");
}
}
