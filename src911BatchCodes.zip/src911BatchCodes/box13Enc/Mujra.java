package box13Enc;

class Father extends Object{    //single inheritance
	
	void gold() {
		System.out.println("2Kg sona..");
	}
}

class Tushar extends Father {
	
	void masti() {
		System.out.println("tubelight fodna");
	}	
}

public class Mujra extends Object {
  public static void main(String[] args) {
	System.out.println("Mujra start");
	
	Tushar t1 = new Tushar(); //object
	t1.gold();
	t1.masti();
	
	System.out.println("--------");
	
	Father f1 = new Father(); //object
	f1.gold();
	//f1.masti(); //CTE
	
	System.out.println("Mujra End");
}
}
