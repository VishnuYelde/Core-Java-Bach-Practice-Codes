package box13Enc;


public class Google {
  public static void main(String[] args) {
	
//	  Employee e1 = new Employee("Hritik",400,70000);
//	//  System.out.println(e1.name);
//	 // System.out.println(e1.empid);
//	 // System.out.println(e1.sal);
//	  
//	  System.out.println(e1.getName()); 
//    System.out.println("-------");
//	  // e1.name="Star Hritik"; 
//	  e1.setName("Star Hritik");
//	  System.out.println(e1.getName());
//	  
//	  System.out.println("----------");
//	  
//	  Employee e2 = new Employee("Sahil",401,80000);
//	  System.out.println(e2.getName());
//	  e2.setSal(90000);
//	  System.out.println(e2.getSal());
	  
	  
	  Integer i1 = 0000234;
	  System.out.println(i1);
}
}



