package box13Enc;

class Champaklal{   //Implicit constructor call
	
	Champaklal(char ch , double d){
		System.out.println(ch+"  "+d+" 1..Inside Champaklal Constructor..");
	}	

}

class Jethalal extends Champaklal{
	
	Jethalal(String s){
		super('A', 55.55);
		System.out.println(s+"  2..Inside Jethalal Constructor..");
	}	
}

class Tappu extends Jethalal{
	
	Tappu(int a, int b){
		super("Cycle");   //calls Super class Constructor
		System.out.println(a+" "+b+" 3..Inside Tappu Constructor..");
	}
}

public class TMKOC {
  public static void main(String[] args) {
	System.out.println("TMKOC start");
	
	Tappu t1 = new Tappu(50 , 90); //Object
	
	System.out.println("TMKOC End");
}
}
