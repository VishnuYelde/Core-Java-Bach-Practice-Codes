package box13Enc;

class Pitaji{
   
	void house() {
		System.out.println("Bada House");
	}
	
	private void house2() {
		System.out.println("Bada House");
	}

}

class Dheeraj extends Pitaji{
	
}

public class Suryavansham {
  public static void main(String[] args) {
	
	  Dheeraj d1 = new Dheeraj();
	  d1.house();
	 // d1.house2();
}
}
