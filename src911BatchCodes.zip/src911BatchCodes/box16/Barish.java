package box16;

class Father{
	int a = 500;
	void house() {
		System.out.println("Big house");
	}
}

class Son extends Father{
	int i = 40;
	void drugs() {
		System.out.println("Cocaine...");
	}
}

class Daughter extends Father{
	int j = 55;
	void makeUp() {		
		System.out.println("Escaping Reality");
	}
}

public class Barish {
  public static void main(String[] args) {
  System.out.println("Barish Start");	
	  Father f1 = new Son();  //upcasting
	  
	  Daughter d1 = (Daughter)f1;   //Downcasting   
	 	                  //ClassCastException
	  System.out.println("Barish End");	  	 	  
}
}
