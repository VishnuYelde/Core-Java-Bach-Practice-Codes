package box7;

import java.util.Scanner;

public class Superman {
   public static void main(String[] args) {
	
	      //to take arry input from the user (1D array)  
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Enter Total Size of Array");
	   int s = sc.nextInt();
	   
	   int[] arr = new int[s];
	  
	   //for loop to Store the element in an array
	   for(int i=0; i<arr.length; i++) {
		   System.out.println("Enter "+i+" element");
		   arr[i]= sc.nextInt();
	   }
	   
	   System.out.println("---------");
	   
	   //for loop to print the elements in an array
	   for(int i=0; i<arr.length; i++) {
		  System.out.println(i+" = "+arr[i]);
	   }
	   
}
}
