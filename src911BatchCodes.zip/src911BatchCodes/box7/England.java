package box7;

public class England {
   public static void main(String[] args) {
	
	   int[] arr = {12,25,15,20,70};
	   int sum = 0;
	   
	   for(int i=0; i<arr.length; i++) 
	   {
		  if(arr[i]%2 ==0) {
			 sum= sum+arr[i]; //sum += arr[i];  
		  }
	   }
	  System.out.println("Sum of all Even Elements is "+sum); 
	   
}
}
