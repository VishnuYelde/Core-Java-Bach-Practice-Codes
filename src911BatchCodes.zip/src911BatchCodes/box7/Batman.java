package box7;

import java.util.Scanner;

public class Batman {
  public static void main(String[] args) {
	
	  Scanner sc = new Scanner(System.in);
	 System.out.println("Enter total rows");
	 int rn = sc.nextInt();
	 System.out.println("Enter total Column");
	 int cn = sc.nextInt();
	 
	 System.out.println("--------");
	 
	 int[][] arr2D = new int[rn][cn];
	
	 //for loop to store elements in 2D array
	 for(int r=0; r<rn ; r++) {
		 for(int c=0; c<cn; c++) {
			 System.out.println("Enter ("+r+","+c+") element"); 
			 arr2D[r][c]= sc.nextInt();
		 }
	 }
	 
	 System.out.println("------");
	 
	 //for loop to Print elements in 2D array
	 for(int r=0; r<rn ; r++) {
		 for(int c=0; c<cn; c++) {
			 System.out.print(arr2D[r][c]+" "); 
		 }
		 System.out.println();
	 }	 
}
}
