package box7;

public class TatyaBitchu {
   public static void main(String[] args) {

	   
	   String str = "Bade Miya Chote Miya55&&"; 
	   int uCount =0;
	   int lCount =0;
	   int nCount =0;
	   int sCount =0;
	   
	   for(int i=0; i<str.length(); i++) {
		  char ch = str.charAt(i);
		  
		  if(ch>=65 && ch<=90) {
			  uCount++;
		  }else if(ch>=97 && ch<=122) {
			  lCount++;
		  }else if (ch>=48 && ch<=57) {
			  nCount++;
		  }else {
			  sCount++;
		  }
	   }
	   
	  System.out.println("UpperCase :"+uCount); 
	  System.out.println("lowerCase :"+lCount); 
	  System.out.println("Number Count :"+nCount); 
	  System.out.println("Special Char :"+sCount); 
}
}
