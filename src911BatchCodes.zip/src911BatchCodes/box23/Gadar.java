package box23;

import java.util.Arrays;

public class Gadar {
  public static void main(String[] args) {
	
	  String str = "Mere Bandi ko hath lagaya Tho Kat dalunga";
	  
	  String[] arr = str.split(" ");
	  
	  for(String s1: arr) {
		  System.out.println(s1);
	  }
	 
	  System.out.println("-----");
	  System.out.println(Arrays.toString(str.split(" ")));
	  //[Mere, Bandi, ko, hath, lagaya, Tho, Kat, dalunga]
}
}
