package box23;

class Shiro{
	
	String s;
	int age ;
	
	//constructor
	public Shiro(String s, int age) {
		super();
		this.s = s;
		this.age = age;
	}	
	                      //Object obj = new Shiro("Chocolate", 16); //upcasting
	public boolean equals(Object obj) {
		Shiro m = (Shiro)obj;   //Downcasting
		return  this.age ==m.age;
	}
}


public class Shinchan {
   public static void main(String[] args) {
    System.out.println("MAin start");
    
    Shiro s1 = new Shiro("Chocolate", 20);
    Shiro s2 = new Shiro("DoraCake", 16);
    
    System.out.println(s1);
    System.out.println(s2);  //address will not be same
    
   //or  System.out.println(s1.equals(new Shiro("Chocolate", 16)));
     System.out.println(s1.equals(s2)); 
    
     System.out.println("----------");
    System.out.println(s1==s2); //false 
    // == will always compare address/ref of two object 
    System.out.println("MAin End");
}
}
