package box23;

class Ninja{
	   //After Overriding
  int a = 600;
  
  void race() {
	  System.out.println("Racing...");
  }	
  
  @Override
  public String toString() {
	  return "Kawasaki Ninja";
  }

}

public class Dodge {
   public static void main(String[] args) {
	System.out.println("Main start");
	
	Ninja n1 = new Ninja();  //Object
	System.out.println(n1); //box23.Ninja@6f539caf
	System.out.println(n1.toString()); //box23.Ninja@6f539caf
	System.out.println("------------------");
	
	Ninja n2 = new Ninja(); //Object 2
	System.out.println(n2);  //box23.Ninja@79fc0f2f
	System.out.println(n2.toString()); //box23.Ninja@79fc0f2f
	
	System.out.println("Main End");
}
}
