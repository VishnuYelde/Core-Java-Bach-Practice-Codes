package box23;

class TMKOC {	
	int num;

	public TMKOC(int num) {
		this.num = num;
	}	
}

public class Champaklal {
	public static void main(String[] args) {
		System.out.println("C Start");
		
		TMKOC t1 = new TMKOC('A');	 //non-String Object
		System.out.println(t1.hashCode()); //1867750575
		
		TMKOC t2 = new TMKOC(786);	  //non-String Object
		System.out.println(t2.hashCode()); //2046562095
		
		System.out.println("-----------");
		
		String s1 = new String("A"); //String Object
		System.out.println(s1.hashCode()); //65
		
		System.out.println("C End");
	}
}
