package box23;

public class MockTest {
	
	//variable argument method
	public static void raju(int ...n) {
		int sum=0;
		for(int i : n) {
			sum=sum+i;
		}
		System.out.println(sum);
	}
	
	
   public static void main(String[] args) {
	System.out.println("Main start");
	
	raju(20,40,60,70);
	raju(200,500);
	raju(5,7,9,2,8,9,2);
	raju(-5,-8,-50);
	
	System.out.println("Main End");
}
}
