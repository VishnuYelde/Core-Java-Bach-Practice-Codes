package box23;

class Kantara {

	String name;

	// constructor
	Kantara(String name) {
		this.name = name;
	}
}

public class JavaScript {
	public static void main(String[] args) {

		Kantara k1 = new Kantara("Prajwal"); // non- String Object
		System.out.println(k1); // box23.Kantara@6f539caf
		System.out.println(k1.toString()); // box23.Kantara@6f539caf

		String s1 = new String("Kunal"); // String Object
		System.out.println(s1); // Kunal
		System.out.println(s1.toString()); // Kunal

		/*
		  a)toString() should have returned string representation of the
		  Object(address) but in String class it is Overridden to return the data
		 */
	}
}
