package box23;

public class Kalli {
  public static void main(String[] args) {
	
	  String str = "Software Engineer";
	  System.out.println(str.length()); //17
	  System.out.println(str.charAt(0)); //S
	  System.out.println(str.charAt(1)); //o
	  System.out.println(str.charAt(16));  //r
	  
	  System.out.println(str.contains("ware")); //true
	  System.out.println(str.contains("eer")); //true
	  
	  System.out.println(str.toLowerCase()); //software engineer
	  System.out.println(str.toUpperCase()); //SOFTWARE ENGINEER
	  
	  System.out.println(str.startsWith("Sof")); //true
	  System.out.println(str.startsWith("En")); //false
	  System.out.println(str.endsWith("ineer")); //true
	  System.out.println(str.endsWith("ngi")); //false
	  
	  System.out.println(str.indexOf('f')); //2
	  System.out.println(str.indexOf('E')); //9
	  System.out.println(str.indexOf('r')); //6
	  System.out.println(str.lastIndexOf('r'));  //16
	  
	  System.out.println(str.indexOf('e')); //7
	  System.out.println(str.lastIndexOf('e')); //15
	  System.out.println(str.indexOf('e', 8)); //14
	  
	  System.out.println(str.isEmpty()); //false
	  
	  System.out.println(str.substring(5)); //are Engineer
	  System.out.println(str.substring(11)); //gineer
	  System.out.println(str.substring(3,7)); //twar
	  
	  System.out.println(str.replace("e", "Robot")); 
	                             //SoftwarRobot EnginRobotRobotr
	  
	  String s2 = "Sab Ke Pas hota , Deta Koye nahi , Deta Koye nahi";
	  System.out.println(s2.replace("Deta", "Money"));
	   //Sab Ke Pas hota , Money Koye nahi , Money Koye nahi
	  
}
}
