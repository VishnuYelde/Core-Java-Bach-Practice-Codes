package box23;

public class Undertaker  {
   public static void main(String[] args) {
	   
	 String s1 = new String("Yogesh"); //String Object
	 String s2 = new String("Renuka");
	 s1.concat(s2); 
	 System.out.println(s1); //Yogesh
	 //String is Immutable in nature
	 
	 String s = "Rohit";
	 s.concat("Kritika");
	 System.out.println(s);   //Rohit
	 //String is Immutable in nature
	 
	 System.out.println("-------");
	 
	 //Stringbuffer /StringBilder  is Mutable version of String
	 StringBuffer s3 = new StringBuffer("Sneha");
	 StringBuffer s4 = new StringBuffer("Roshan");
	 s3.append(s4); 
	 System.out.println(s3);  //SnehaRoshan
	  
	 System.out.println("------");
	 
	 StringBuilder s5 = new StringBuilder("Shilpa");
	 s5.append("Varun");
	 System.out.println(s5); //ShilpaVarun
}
}
