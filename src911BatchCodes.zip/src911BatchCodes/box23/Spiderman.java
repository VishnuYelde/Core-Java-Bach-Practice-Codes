package box23;

class IronMan{
	
	int num;

	//Constructor
	public IronMan(int num) {
		this.num = num;
	}	
}

public class Spiderman {
  public static void main(String[] args) {
	System.out.println("S start");
	
	IronMan i1 = new IronMan(3000); //non-String Object
	IronMan i2 = new IronMan(3000); //non-String Object
	System.out.println(i1.equals(i2)); //false
	//equals method compares the address of two objects
	
	System.out.println("---------");
	
	String s1 = new String("Hritik");  //String Object
	String s2 = new String("Hritik");  //String Object
	System.out.println(s1.equals(s2));  //true
	//in string class equals() is Overridden to compare the data not address
	
	System.out.println("S End");
}
}
