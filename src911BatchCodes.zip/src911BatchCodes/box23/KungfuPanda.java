package box23;

class Hardik extends Object{    //after Overriding hashCode()
	
	static int n = 143;
	
	@Override
	public int hashCode() {
		return n++;
	}	
}

public class KungfuPanda {
  public static void main(String[] args) {
	
	  Hardik h1 = new Hardik();
	  System.out.println(h1.hashCode()); //143
	  
	  System.out.println("------");
	  
	  Hardik h2 = new Hardik();
	  System.out.println(h2.hashCode()); //144
	  
      System.out.println("------");
	  
	  Hardik h3 = new Hardik();
	  System.out.println(h3.hashCode()); //145
	  
	  Integer i1 = new Integer(567);
	  char ch ='A';
	  Character c1 = 'T';
	  
	  
	  String s = "Kunal";
}
}
