package box6;

public class Dubai {
  public static void main(String[] args) {
	
	  String[] burjK = {"Salman","Mia","Bhaskar","Sunny"
			  ,"Shubham","Aditya","Alina","Chinmay","Bhavika",
			  "Danny","Suyesh","Chetna","Kunal","Savita"
			  ,"Kalpana","Harshada","Dinchak Pooja"};
	  
	 System.out.println(burjK.length); //length 17
	 //index start from 0 to 16
	 
//	 System.out.println(burjK[0]);
//	 System.out.println(burjK[1]);
//	 System.out.println(burjK[2]);
//	 System.out.println(burjK[3]);
	    //it will take more time , and space
	 
	 for(int i=0; i<burjK.length; i++) {
		System.out.println("Room No "+i+"--> "+burjK[i]); 
	 }
	 
	 
}
}
