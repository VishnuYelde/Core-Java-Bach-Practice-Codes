package box6;

public class Shubham {
  public static void main(String harshad[]) {
	
	  
	  int[] arr = {45,10,30,70,45};
	  System.out.println(arr[0]);
	  System.out.println(arr[4]);
}
}
