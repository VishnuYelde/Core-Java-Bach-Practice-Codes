package box6;

public class Occurance {
   public static void main(String[] args) {
	
	   int[] arr = {2,3,5,2,3,4,5,5,2,1,1,3,4,5,2,1,1};
	   int key = 2;
	   int count =0;
	   
	   for(int i=0; i<arr.length; i++) {
		   if(arr[i]==key) {
			   count++;
		   }
	   }
	   System.out.println(key+" has Occured "+count+" times");
}
}
