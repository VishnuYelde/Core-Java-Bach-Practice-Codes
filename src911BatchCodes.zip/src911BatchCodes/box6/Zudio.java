package box6;

public class Zudio {
  public static void main(String[] args) {
	
	  int[] arr = new int[5];
	  arr[0]=7;
	  arr[1]=25;
	  arr[2] = 45;
	  arr[3]=80;
	  arr[4]=53;
	  
	  System.out.println(arr[0]);
	  System.out.println(arr[1]);
	  System.out.println(arr[2]);
	  System.out.println(arr[3]);
	  System.out.println(arr[4]);
}
}
