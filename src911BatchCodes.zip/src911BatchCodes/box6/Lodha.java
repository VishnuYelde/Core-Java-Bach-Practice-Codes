package box6;

public class Lodha {
  public static void main(String[] args) {
	
     int[] nr ;  //array declaration
        nr= new int[6];  //array Creation 
   
    String[] menu = new String[4] ; 
           //array decalartion and creation
    
    System.out.println(menu[0]); //null
    System.out.println(menu[1]);  //null
    System.out.println(menu[2]);  //null
    System.out.println(menu[3]); //null
                           
    //terrace
    //System.out.println(menu[4]); //ArrayIndexOutOfBoundsException
   // System.out.println(menu[20]); //ArrayIndexOutOfBoundsException
        
     System.out.println("-------------");
    menu[0] = "Poha";      //array Initialization
    menu[2] = "Falooda";
    
    System.out.println(menu[0]); //Poha
    System.out.println(menu[1]);  //null
    System.out.println(menu[2]);  //Falooda
    System.out.println(menu[3]); //null    
}
}
