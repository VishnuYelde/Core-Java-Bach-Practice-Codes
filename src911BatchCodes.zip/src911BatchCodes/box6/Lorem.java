package box6;

public class Lorem {
  public static void main(String[] args) {
	
	  int[] arr = {20,35,55,12,35,75,95,79,68,77};
	  int max = arr[0];
	  System.out.println(arr.length); //10
	              //index 0 to 9
	  
	  for(int i=0; i<arr.length; i++)
	  {
		  if(arr[i]>max) {
			  max=arr[i];
		  }
	  }
	  
	  System.out.println("Maximum Element is "+max);
	  
}
}
