package box6;

public class Egypt {
  public static void main(String[] args) {
	   //Floyd's Triangle
	  int n = 5;
	 
	  for(int r=n; r>=1; r--)   //Outer For loop
	  {
		  //spaces  //inner for loop 1
		  for(int s=1; s<=(n-r); s++) {
			 System.out.print("   "); 
		  }
		  
		  int num = 10;
		  //stars  //inner for loop 2
		  for(int k=1; k<=(2*r)-1 ; k++) {
			  System.out.print(num+" ");
			  num+=2;
		  }
	    System.out.println();  
	  }
}
}
