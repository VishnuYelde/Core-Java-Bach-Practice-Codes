package box6;

public class Guru {
  public static void main(String[] args) {
	
	int n = 10; 
	  for(int r=n; r>=1; r--)   //Outer For loop
	  {
		  //spaces  //inner for loop 1
		  for(int s=1; s<=(n-r); s++) {
			 System.out.print("  "); 
		  }
		  
		  //stars  //inner for loop 2
		  for(int k=1; k<=(2*r)-1 ; k++) {
			  System.out.print("* ");
		  }
	    System.out.println();  
	  }
	
}
}
