package box6;

public class PrimeLoop {
	
	public static boolean isPrime(int num)
	{
		if(num<=1) {
			return false;
		}
		
		for(int i=2; i<=Math.sqrt(num); i++) {
			if(num%i ==0) {
				return false;
			}
		}	
		return true;
	}
	
	  
	public static void main(String[] args) {
		System.out.println("Main Start");
		
		for(int i=100; i<=130; i++) {
			if(isPrime(i)) {
				System.out.println(i+" is Prime");
			}
		}
		
		
		System.out.println("Main End");
	}
}
