package box6;

public class Daddy {
	
	public static void diamond(int n) {
			
		  //First half
		  for(int r=6; r<=n; r++)   //Outer For loop
		  {
			  //spaces  //inner for loop 1
			  for(int s=1; s<=(n-r); s++) {
				 System.out.print("  "); 
			  }
			  
			  //stars  //inner for loop 2
			  for(int k=1; k<=(2*r)-1 ; k++) {
				  System.out.print("* ");
			  }
		    System.out.println();  
		  }
		
		
		  //second half
		  for(int r=n-1; r>=1; r--)   //Outer For loop
		  {
			  //spaces  //inner for loop 1
			  for(int s=1; s<=(n-r); s++) {
				 System.out.print("  "); 
			  }
			  
			  //stars  //inner for loop 2
			  for(int k=1; k<=(2*r)-1 ; k++) {
				  System.out.print("O ");
			  }
		    System.out.println();  
		  }
	}
	
	
  public static void main(String[] args) {
	
	  System.out.println();
	  System.out.println();
	  System.out.println();
	  System.out.println();
	  
	diamond(9);
	  
	
}
}
