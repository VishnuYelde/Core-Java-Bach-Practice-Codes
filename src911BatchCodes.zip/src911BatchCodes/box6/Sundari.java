package box6;

public class Sundari {
  public static void main(String[] args) {
	
	  int[] arr = {20,35,55,12,35,75,95,79,68,77};
	  int min = arr[0];
	  System.out.println("Length -"+arr.length); //10
	              //index 0 to 9
	  
	  for(int i=0; i<arr.length; i++)
	  {
		  if(arr[i]<min) {
			  min=arr[i];
		  }
	  }
	  
	  System.out.println("Smallest Element is "+min);
}
}
