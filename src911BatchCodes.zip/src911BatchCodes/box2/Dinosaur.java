package box2;

public class Dinosaur {
  public static void main(String[] args) {
	System.out.println("Main Start");
	  int i=1;
	  
	  while(i<=10)
	  {
		  if(i%2 ==0) {
			  System.out.println(i);
		  }
		  i++;
	  }	  
	  System.out.println("Main End");
}
}
