package box2;

public class Siddhesh {
   public static void main(String[] args) {
	System.out.println("Main Start");
//	  for(int i=150; i>=100; i--) {
//		  System.out.println(i);
//	  }
	
//	for(int i=-20; i<=0; i+=2) {
//		System.out.println(i);
//	}
	
//	for(int i=-20; i<=0; i++) {
//		if(i%2 != 0) {
//			System.out.println(i);
//		}
//	}
	
	
	for(int i=160; i<=180; i++) {
		if(i%3 == 0) {
			System.out.println(i);
		}
	}
	   System.out.println("Main End");
}
}
