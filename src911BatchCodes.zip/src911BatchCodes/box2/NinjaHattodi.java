package box2;

public class NinjaHattodi {
  public static void main(String[] args) {
	System.out.println("M start");
       for(int i=1; i<=10 ; ++i)
       {
    	   System.out.println(i+" Ding Ding");
       }
	
       System.out.println("M End"); 
}
}
