package box2;

public class DalChawal {
  public static void main(String[] args) {
	
	  for(int i=97; i<=122; i++)
	  {
		  System.out.print((char)i+" ");
	  }
	  
	  System.out.println("-----");
	  System.out.println("-----");
	  
	  for(char ch = 122; ch>=97; ch--) {
		System.out.print(ch+" ");  
	  }
}
}
