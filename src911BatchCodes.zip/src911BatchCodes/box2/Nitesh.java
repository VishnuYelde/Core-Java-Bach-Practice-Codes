package box2;

public class Nitesh {
  public static void main(String[] args) {
	
	  for(int i=30; i>=1; i--) {
		  if(i%15 ==0) {
			  System.out.println(i);
		  }
	  }
}
}
