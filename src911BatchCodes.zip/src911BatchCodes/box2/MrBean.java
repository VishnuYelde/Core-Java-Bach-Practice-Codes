package box2;

public class MrBean {
  public static void main(String[] args) {
	
	  for(int i =1,j=65 ; (i<=26 && j<=90); i++ ,j++) {
		  
		  System.out.println(i+" "+(char)j+"-->"+j);
	  }
}
}
