package box2;

public class Pokemon {
 public static void main(String[] args) {
	
	 for(int i=1 ; i<=20; i+=2)
	 {
		 System.out.println(i);
	 }
}
}
