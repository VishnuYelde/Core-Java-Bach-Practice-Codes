package box2;

public class TomJerry {
  public static void main(String[] args) {
	
	 System.out.println((char)65);  //A
	 System.out.println((char)66);  //B
	 System.out.println((char)90);  //Z
	 System.out.println((char)122);  //z
	 
	 System.out.println("-----"); 
	 
	  for(char ch ='A'; ch<='Z'; ch++) {
		  System.out.println(ch);
	  }	  
}
}
