package box2;

public class ShinChan {
   public static void main(String[] args) {
	
	   for(int i=49; i>=30; i-=2) {
		   System.out.println(i);
	   }
	   
	System.out.println("--------");
	
	   for(int i = 50; i>=30; i--) {
		   if(i%2 != 0) {
			 System.out.println(i);  
		   }
	   }
}
}
