package box4;

public class OptimusPrime {
   
	public static boolean isPrime(int num)
	{
		if(num<=1) {
			return false;
		}
		
		for(int i=2; i<=Math.sqrt(num); i++) {
			if(num%i ==0) {
				return false;
			}
		}
		
		return true;
	}
	
	public static void main(String[] args) {
		System.out.println("MAin start");
		
		int n =7;
		
		if(isPrime(n)) {
			System.out.println(n+" is Prime");
		}else {
			System.out.println(n+" is Not Prime");
		}
		
		System.out.println("MAin End");
	}
}
