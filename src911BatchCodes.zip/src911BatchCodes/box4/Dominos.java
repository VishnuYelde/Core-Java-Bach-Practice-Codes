package box4;

public class Dominos {
	
	public static void area(double rad) {
		System.out.println("Area start");
		double area = 3.142*rad*rad;
		System.out.println("Area of Pizza is "+area);
		System.out.println("Area End");
	}
  
	public static void main(String[] args) {
		System.out.println("Main start");
		
		area(10);
		
		area(5);
		
		area(3.2);
		
		System.out.println("Main End");
	}
}
