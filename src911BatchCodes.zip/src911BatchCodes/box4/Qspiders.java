package box4;

public class Qspiders {
	
	public static void tiger() {
		System.out.println("Tiger start");
		 tiger();
		System.out.println("Tiger End");
	}
	
  public static void main(String[] args) {
	System.out.println("Main start");
	tiger();
	System.out.println("Main End");
}
}
