package box4;

public class Pandit {
    
	 static void motu(double a , double b , double c) 
	 {
		System.out.println("Motu Start"); 
		      //double avg = (a+b+c)/3;
		System.out.println("Average is "+((a+b+c)/3));		
		System.out.println("Motu End"); 
	 }
	
		
	public static void main(String[] args) {
		System.out.println("Main Start");
		
		motu(55,60,70);
		
		motu(24,56,79);
		
		System.out.println("Main End");
	}
	
}
