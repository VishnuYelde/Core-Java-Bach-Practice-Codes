package box4;

public class Mango {
   
	 // 1 without return type without parameter method
	
	public static void dolly() {
		System.out.println("Dolly Start");
		int x =700, y = 120;
		System.out.println(x+y);
		System.out.println("Dolly End");
	}
	
	public static void main(String[] args) {
		System.out.println("M start");
		dolly();
		dolly();
		dolly();
		
		System.out.println("M End");
	}
}
