package box4;

public class Kalia {
	
	//4 with retrun type with parameter
	public static double area(double b , double h) {
		double an = 0.5*b*h;
		return an;
	}
	
	//3 with return type without parameter
	public static int chutki() {
		return  150;
	}
	
	
  public static void main(String[] args) {
    System.out.println("Main Start");
    
   System.out.println( chutki()); //150
   System.out.println( chutki()); //150
   
   System.out.println("-------");
   int res = chutki()+chutki()+chutki();
   System.out.println(res);
   
   System.out.println("-------");
   System.out.println( area(5,7));
   System.out.println( area(10,15));
   System.out.println( area(6,4));
   
    System.out.println("Main End");
}
}
