package box4;

public class Taj {
	
	public static void chotu(int a, int b)
	{
	   System.out.println("Chotu start");
	   System.out.println(a+b);
	   System.out.println("Chotu End");	
	}
	
  public static void main(String[] args)
  {
	System.out.println("Main Start");
	chotu(24,56);	
	chotu(72,90);
	chotu(60,'A');
	
	System.out.println("Main End");	
  }
}
