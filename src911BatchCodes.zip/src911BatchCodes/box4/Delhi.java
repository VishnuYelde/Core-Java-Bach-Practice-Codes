package box4;

public class Delhi {
	
	public static void chotu() {
		System.out.println("Chotu start ");
		
		System.out.println("Chotu End ");
	}
	
	public static void motu() {
		System.out.println("Mo start ");
		
		System.out.println("Mo End ");
	}

  public static void main(String[] args) {
	System.out.println("Main start");
	
	chotu();
	
	motu();
	
	System.out.println("Main End");
}
}
