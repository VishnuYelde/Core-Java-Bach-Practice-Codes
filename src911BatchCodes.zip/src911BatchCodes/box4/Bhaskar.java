package box4;

import java.util.Scanner;

public class Bhaskar {
	
	public static double avg(double a, double b, double c) {
		return (a+b+c)/3;
	}
	
	
   public static void main(String[] args) {
	System.out.println("Main Start");
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter 1st Match score");
	int s1 = sc.nextInt();
	System.out.println("Enter 2nd Match score");
	int s2 = sc.nextInt();
	System.out.println("Enter 3rd Match score");
	int s3 = sc.nextInt();
	
	
	double ans = avg(s1,s2,s3);
	System.out.println("Average is "+ans);
	
	if(ans>=0 && ans<=50) {
		System.out.println("Player Out of Form");
	}else if (ans>50 && ans<80) {
		System.out.println("Good Player");
	}else if(ans>=80) {
		System.out.println("GOAT Player");
	}else {
		System.out.println("Invaild Result");
	}
	  
	System.out.println("Main End");
}
}
