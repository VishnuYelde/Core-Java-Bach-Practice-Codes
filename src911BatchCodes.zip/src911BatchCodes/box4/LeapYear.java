package box4;

public class LeapYear {
   public static void main(String[] args) {
	
	   int year = 2004;
	   
	    boolean res = (year%400 ==0) || (year%4 ==0  &&  year%100 !=0) ;
	    
	    if(res) {
	    	System.out.println(year+" is Leap Year");
	    }else {
	    	System.out.println(year+" is Not-Leap Year");
	    }
}
}
