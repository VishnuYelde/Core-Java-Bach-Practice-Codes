package box4;

import java.util.Scanner;

public class PizzaHut {
	
	public static double area(double rad) {
		double ans = 3.142*rad*rad;	
		return ans;
	}
	
  public static void main(String[] args) {
	System.out.println("Main Start");
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the size of Pizza");
	int num = sc.nextInt();
	double s = area(num);
	System.out.println("Area of "+num+" inch Pizza is "+s);
	
	if(s>0 && s<=100) {
		System.out.println("Small size Pizza");
	}else if(s>100 && s<=250) {
		System.out.println("Midium Size Pizza");
	}else if(s>250) {
		System.out.println("Large Pizza");
	}else {
		System.out.println("Andhe Hai Kya..Invalid");
	}
	   	
	System.out.println("Main End");
}
}
