package box4;

public class Fatichar {
	//4 with return type with parameter method
	public static double raju(double a , double b, double c) {
		
		return  (a+b+c)/3;
		
	}
	
	
   public static void main(String[] args) {
	System.out.println("Main Start");
	
	System.out.println(raju(0,100,200)); //printing result directly
	
	   double ans = raju(50,40,30); //storing ans in diff variable
	   System.out.println(ans);
	   
	   System.out.println(raju(20,50,70));
	
	System.out.println("Main End");
}
}
