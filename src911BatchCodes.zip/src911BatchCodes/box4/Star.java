package box4;

public class Star {
  public static void main(String[] args) {

	  for(int r=1; r<=5; r++) 
	  {
		  for(int c=1; c<=5; c++) 
		  {
			  System.out.print("* ");
		  }
		  System.out.println();
	  }
}
}
