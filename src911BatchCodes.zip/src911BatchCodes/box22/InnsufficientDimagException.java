package box22;

//custom unchecked Exception
public class InnsufficientDimagException  extends RuntimeException{
 
	@Override
	public String getMessage() {
		return "Dimag Nahi Hai Kya..Balance Kam Hai";
	}
}
