package box22;

import java.util.Scanner;

public class Umar {
  public static void main(String[] args) {
	System.out.println("Main start");
	  Scanner sc= new Scanner(System.in);
	  System.out.println("Enter ur age(+ve Number)");
	  int n = sc.nextInt();
	  
	  if(n<0) {
		  try {
		 throw new AnpadException();
		  }catch(AnpadException a1) {
			  System.out.println(a1.getMessage());
		  }finally {
			  sc.close();
		  }
	  }else {
		  System.out.println("Entered Age is Correct");
	  }
	  
	  System.out.println("Main End");
}
}
