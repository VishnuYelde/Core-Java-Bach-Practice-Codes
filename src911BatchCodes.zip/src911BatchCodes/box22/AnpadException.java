package box22;

//custom checked exception
public class AnpadException extends Exception{
  
	@Override
	public String getMessage() {
		return "Negative num Nahi Likhne Ka..Anpad Hai kya?? ";
	}
}
