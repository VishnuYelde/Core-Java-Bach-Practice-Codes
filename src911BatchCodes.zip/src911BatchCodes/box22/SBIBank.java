package box22;

import java.util.Scanner;

public class SBIBank extends Object {
   public static void main(String[] args) {
	System.out.println("Main start");
	
	 int bal = 15000;
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter amt you like to Withdraw");
	int wAmt = sc.nextInt();
	
	if(bal>= wAmt) {
		System.out.println(wAmt+" Withdrawed Successfully");
	}else {
		try {
		 throw new InnsufficientDimagException();
     //InnsufficientDimagException i1 = new InnsufficientDimagException();
      //throw i1;
		}catch(InnsufficientDimagException i) {
			System.out.println(i.getMessage());
		}finally {
			sc.close();
		}
	}
	System.out.println("Main End");
}
}
