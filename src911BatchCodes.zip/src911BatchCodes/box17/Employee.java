package box17;

public class Employee extends Person{

	String empid;
	double sal;
	String design;
	
	public Employee(String name, int age, char gen, 
			String empid, double sal, String design) {
		super(name, age, gen);
		this.empid = empid;
		this.sal = sal;
		this.design = design;
	}
	
	@Override
	void jankari() {
		System.out.println("Employee name is "+name+" Age is "+age+"  Gender is "+gen
				+"  Empid is "+empid+"  Salary "+sal+"  Designation "+design);
	}
	
	
}
