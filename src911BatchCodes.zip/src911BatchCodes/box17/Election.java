package box17;

public class Election {
  public static void main(String[] args) {
	
	  Government g1 = new  Government();
	  
	  Person p1 = new Person("Champaklal",75, 'M');
	  Student s1 = new Student("Dheeraj",21,'M',2,63.54,"DMC College");
	  Employee e1 = new Employee("Adnan",22,'M',"TCS540",185000,"SDE");
	
	  //generalization
	  g1.aadhaar(p1);
	  g1.aadhaar(s1);
	  g1.aadhaar(e1);
	  g1.aadhaar(new Student("Kunal",22,'M',69,35.45,"Saraswati"));
	  
	  System.out.println("-----------------");
	  //specialization
	//  g1.scholarship(p1); //CTE
	  g1.scholarship(s1);
	 // g1.scholarship(e1); //CTE
	  
	  System.out.println("--------------");
	  //specialization
	  //g1.taxPayment(p1); //CTE
	  //g1.taxPayment(s1); //CTe
	  g1.taxPayment(e1);
}
}
