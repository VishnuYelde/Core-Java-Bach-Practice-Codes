package box17;

public class Government {

	//generalized method   Person p = new Student("Kunal",22,'M',69,35.45,"Saraswati");
	public  void aadhaar(Person p) {
		System.out.println(p.name+" will get Aadhaar Card");
	}
	
	//specialized method
	public void scholarship(Student s) {
	  if(s.per >= 70) {
		  System.out.println(s.name+" will get ScholarShip");
	  }else {
		  System.out.println(s.name+" Ladki pe kam , Padaye pe Dhayn Do");
	  }
	}
	
	public void taxPayment(Employee e) {
		if(e.sal*12 >= 1200000) {
			System.out.println(e.name+" Should pay tax");
			System.out.println(e.name+" Should pay 18% tax "
					+ "Tax Payable is = "+(e.sal*12*0.18)+" rs/only");
		}else {
			System.out.println(e.name+" Tax dene ke jarurat Nahi hai..");
		}
	}
}
