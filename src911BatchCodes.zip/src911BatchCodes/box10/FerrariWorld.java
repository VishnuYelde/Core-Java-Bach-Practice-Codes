package box10;

class Ferrari {
	
	String colour = "Red";  //non-static global var
	int  speed = 240;
	double price = 455;
	
	void details() {   //non-static method
		System.out.println("Ferrari Colour :"+colour
				+"  Speed is  "+speed+"  Price:"+price);
	}
}

public class FerrariWorld {
   public static void main(String[] args) {
	System.out.println("FW start");
	
	Ferrari f1 = new Ferrari();	 //Object 1
	Ferrari f2 = new Ferrari();  //Object 2
	//System.out.println(f1.colour);
	//System.out.println(f1.price);  //lengthy way so we created method
	
	f1.details();
	f2.details();
	System.out.println("-----------");
	f1.colour = "Yellow"; //f1 clour change
	 f2.speed= 280;   //f2 speed change
	
	    f1.details();
		f2.details();
	System.out.println("FW End");	   
}
}










