package box10;

class Account
{
  String email;
  long phno;
  String pass;
  
  //Constructor 1
  public Account(String email, String pass) {
	this.email = email;
	this.pass = pass;
	System.out.println("Inside Constructor 1");
  }

//Constructor 2
  public Account(long phno, String pass) {
	this.phno = phno;
	this.pass = pass;
	System.out.println("Inside Constructor 2");
  }
  
 void loginDetails() {  //non-static method
	 System.out.println("User Email:"+email+" Contact Num:"
              +phno+"  Password:"+pass);
 } 	
}


public class Email {
   public static void main(String[] args) {
	
	   Account a1 = new Account("AtalPhulkumari@gmail.com","143Pulkumari");
	   a1.loginDetails();
	   
	   System.out.println("---------");
	   
	   Account a2 = new Account(987654321L, "Vivek@786");
	   a2.loginDetails();
	   
	   System.out.println("----------");
	   
	   Account a3 = new Account("Kunal@gmail.com","Kunl@003");
	   a3.loginDetails();
}
}
