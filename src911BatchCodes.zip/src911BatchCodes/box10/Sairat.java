package box10;

public class Sairat {
	
	static {   //Static block 1
		System.out.println("Riya Joined Qspiders");
	}
	
	static {   //Static block 2
		System.out.println("Dheeraj is Very Happy");
	}
	
  public static void main(String[] args) {
	System.out.println("Main start");
	
	System.out.println("Main End");
   }
  
  static {   //Static block 3
		System.out.println("Riya Got Placed..");
	}
  
    static {  //static block 4
    	System.out.println("Dheeraj became Devdas..");
    }
}
