package box10;

public class Vimal {
	
	static String str ; //static global var
	      int age ;   //non-static global var
	      
	      {      //non-static block 1
	    	    // str="Vipul"; //not good practice
	    	  age = 20;
	    	  System.out.println("Non-static block 1");
	      }
	      
	      {      //non-static block 2
	    	  age = 38;
	    	  System.out.println("Non-static block 2");
	      }
	
  public static void main(String[] args) {
	System.out.println("Main Start");
	
	Vimal v1 = new Vimal(); //Object 1
	System.out.println(v1.age); //45
	
	System.out.println("Main End");
  }
  
  
	{      //non-static block 3
  	    age = 45;
  	  System.out.println("Non-static block 3");
    }  
     
}
