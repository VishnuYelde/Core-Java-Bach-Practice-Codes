package box10;

class Rum {  //Constructor Overloading
	
	Rum(){   //constructor 1
		System.out.println("No-parameter Const");
	}
	
	Rum(int a){   //constructor 2
		System.out.println("1 int parameter Const");
	}
	
	Rum(double a){   //constructor 3
		System.out.println(" 1 double parameter Const");
	}
	
	Rum(int a , double b){   //constructor 4
		System.out.println("2 int,double parameter Const");
	}
	
	Rum(double a , int b){   //constructor 5
		System.out.println("2 double,int parameter Const");
	}

}

public class OldMonk {
  public static void main(String[] args) {
	System.out.println("Main start");
	
	Rum r2 = new Rum(10);
	Rum r3 = new Rum(5.7);
	Rum r4 = new Rum(30.5 , 20);
	
	System.out.println("Main End");
}
}
