package box10;

class Fortuner
{
    String colour;
    int speed;
    double mileage;
    
    //Constructor
  public  Fortuner(String c, int s, double m){
    	System.out.println("Const start");
    	colour =c;
    	speed =s;
    	mileage=m;
    	System.out.println("Const End");
    }
	
    void info() {
    	System.out.println("Fortuner Colour:"+colour
    			+" Speed is:"+speed+" Mileage is "+mileage);
    }
}



public class Toyota {
   public static void main(String[] args) {
	System.out.println("Toyota Start");
	
	Fortuner f1 = new Fortuner("Black",180,15);
	f1.info();
	
	System.out.println("--------");
	
	Fortuner f2 = new Fortuner("White",200, 12);
	f2.info();	
	
	System.out.println("---------");
	
	Fortuner f3 = new Fortuner("HotPink", 150, 10);
	f3.info();
	
	System.out.println("Toyota End");
	   
}
}
