package box10;

public class Suyash {
	
	static String s;
	
	static {   //static block 1
		s="Babu";
		System.out.println("static B 1");
	}
	
	static { //static block 2
		s="Sheela";
		System.out.println("static B 2");
	}
	
  public static void main(String[] args) {
	System.out.println("Main start");
	
	System.out.println(Suyash.s); 
	
	System.out.println("Main End");
}
  
  static { //static block 3
	  s="Disha";
		System.out.println("static B 3");
  }
}
