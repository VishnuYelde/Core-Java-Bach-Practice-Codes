package box10;

class CyberCab
{
  static String colour;
   int price;
   double bCap;
   
   void info() {
	   System.out.println("CyberCab Colour is "+colour
			   +" Price is "+price+" Battery Capacity is "+bCap);
   }
	
}

public class Tesla {
  public static void main(String[] args) {
	 
	  CyberCab c1 = new CyberCab();
	  CyberCab c2 = new CyberCab();
	  CyberCab c3 = new CyberCab();
	  c1.info();
	  c2.info();
	  c3.info();
	  System.out.println("----------");
	  c1.colour= "Black";
	  c2.colour="Pink";
	  c3.colour="Blue";
	  c1.info();
	  c2.info();
	  c3.info();	  
	  
}
}
