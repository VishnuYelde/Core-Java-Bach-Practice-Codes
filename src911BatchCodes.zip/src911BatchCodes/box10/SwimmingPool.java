package box10;

public class SwimmingPool {
	
	static String n;
	       int age;
	       
	      //Constructor 
	     SwimmingPool(){
	    	 age=40;
	    	 System.out.println("Inside SP Constructor");  
	       }
	       
	       
	static {  //Static block 1
		n = "Sahil";
		System.out.println("Static block 1");
	}
	
	{   //Non-static block 1
		age = 22;
		System.out.println("Non-static block 1");
	}
	
	
  public static void main(String[] args) {
	System.out.println("Main start");
	
	SwimmingPool s1 = new SwimmingPool(); //Object
	System.out.println(s1.age);
	
	System.out.println("Main End");
  }
  
  static {  //Static block 2
		n = "Dheeraj";
		System.out.println("Static block 2");
	}
  
  {   //Non-static block 2
		age = 20;
		System.out.println("Non-static block 2");
	}
  
  static {  //Static block 3
		n = "Adnan";
		System.out.println("Static block 3");
	}
}
