package box10;


class Employee
{
	      String name;
	final  String empid;
	     double sal;
	private static int randomnum = 900;   
	
	public Employee(String name, double sal) {
		this.name = name;
		this.empid = "2025WIP"+randomnum++;
		this.sal = sal;
	}
	
//	void info() {
//		System.out.println("Employee Name:"+name
//				+" EmpID:"+empid+" Salary:"+sal);
//	}
	
	@Override
	public String toString() {
		return "Employee Name:"+name+" EmpID:"+empid+" Salary:"+sal;
	}
	
}


public class Wipro {
  public static void main(String[] args) {
	System.out.println("Wipro start");
	
	Employee e1 = new Employee("Himanshu",85000);
	Employee e2 = new Employee("Sufiyan",90000);
	Employee e3 = new Employee("Vipul",8500);
	Employee e4 = new Employee("Kunal",100100);
	Employee e5 = new Employee("Ashish",70000);
	Employee e6 = new Employee("Alok",85000);
	Employee e7 = new Employee("Abhay",82000);
	
	System.out.println(e1);
	System.out.println(e1);
	System.out.println(e1);
	System.out.println("----------");
	System.out.println(e2);
	System.out.println(e2);
	System.out.println(e4);
	
	
//	e1.info();
//	e2.info();
//	e3.info();
	
	System.out.println("-------");
//	e3.empid=501;
//	e2.empid=502;
	
//	e1.info();
//	e2.info();
//	e3.info();
//	e4.info();
//	e5.info();
//	e6.info();
//	e7.info();
	
	
	System.out.println("Wipro End");
}
}
