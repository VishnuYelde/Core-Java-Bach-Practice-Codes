package box10;

public class Pizza { 
	
	{    //Non-static block 1
		System.out.println("Non-static block 1");
	}
	
	{    //Non-static block 2
		System.out.println("Non-static block 2");
	}
   
	
	public static void main(String[] args) {
		System.out.println("Main start");
		  
		Pizza p1 = new Pizza();  //Object 1
		System.out.println("------");
		Pizza p2 = new Pizza();  //Object 2
		
		System.out.println("Main End");
	}
	
	{    //Non-static block 3
		System.out.println("Non-static block 3");
	}
}
