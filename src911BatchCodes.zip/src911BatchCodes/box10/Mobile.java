package box10;

class Samsung{

	int ram = 8; //non-static global var
	int mp = 200;
	
	//constructor
	 Samsung(){
		System.out.println("Constructor start");
		
		System.out.println("Constructor End");
	}
	
	void info() { //non-static method
		System.out.println("Mobile Ram is :"+ram+"  MegaPixel :"+mp);
	}

}

public class Mobile {
   public static void main(String[] args) {
	System.out.println("Mobile start");
	
	Samsung s1 = new Samsung();  //Object
	System.out.println("-----------------");
	Samsung s2 = new Samsung();  //Object
	System.out.println("-----------------");
	Samsung s3 = new Samsung();  //Object
	
	System.out.println("Mobile End");
}
}

