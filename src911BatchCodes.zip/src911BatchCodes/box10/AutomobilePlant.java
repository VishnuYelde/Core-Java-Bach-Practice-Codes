package box10;

class RollsRoyce
{
	String colour;
	int price;
	int horpow;
	
	//Constructor
	public RollsRoyce(String colour, int price, int horpow) {
		this.colour = colour;
		this.price = price;
		this.horpow = horpow;
		System.out.println("this keyword Contains:"+this);
	}

	void info() {
		System.out.println("RollsRoyce Colour:"+colour
				+" Price:"+price+"  HorsePower is "+horpow);
	}
	
}


public class AutomobilePlant {
   public static void main(String[] args) {
	
	   RollsRoyce r1 = new RollsRoyce("Gold",900,450); //Object
	   System.out.println("r1 contains: "+r1);
	   r1.info();
	   System.out.println("--------");
	   
	   RollsRoyce r2 = new RollsRoyce("HotPink",1100,350);
	   System.out.println("r2 contains :"+r2);
	   r2.info();
	   
	   System.out.println("----------");
	   
	   RollsRoyce r3 = new RollsRoyce("White",960,400);
	   System.out.println("r3 :"+r3);
	   r3.info();
}
}
