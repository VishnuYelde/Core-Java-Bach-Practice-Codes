package box10;

public class Dabangg {
  public static void main(String[] args) {
	
	final String s = "Sufiyan";
	        // s= "Disha";
	         
	    System.out.println(s);  
	    
	  final  double pi = 3.142;
	         //pi=6.541;
	   //final variables cannot be reinitialized      
	         System.out.println(pi);
	    
  }
}
