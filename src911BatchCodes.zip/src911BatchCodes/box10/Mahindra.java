package box10;

class Thar{
	
	String colour;
	int price;
	double mileage;
	
	void details() {
		System.out.println("Thar colour is "+colour
				+" Price is "+price+" Milage is "+mileage);
	}
}

public class Mahindra {
  public static void main(String[] args) {
	System.out.println("Mahindra start");
	
	Thar t1 = new Thar();
	Thar t2 = new Thar();
	
	t1.details();
	t2.details();
	System.out.println("---------");
	t1.colour = "Black";
	t1.price = 18;
	t1.mileage = 7;
	
	t2.colour="White";
	t2.price =17;
	t2.mileage = 6.5;
	
	t1.details();
	t2.details();
	
	
	System.out.println("Mahindra End");
}
}
