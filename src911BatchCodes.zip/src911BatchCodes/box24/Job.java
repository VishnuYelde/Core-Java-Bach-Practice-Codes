package box24;

import java.util.ArrayList;

public class Job {
   public static void main(String[] args) {
	
	   ArrayList<Object> a1 = new ArrayList<Object>();
	   a1.add("Sandeep");
	   a1.add("Harshal");
	   a1.add("Kunal");
	   a1.add(786);
	   a1.add(true);
	   a1.add("Tanmay");
	   
	   System.out.println(a1);
	   a1.add(2,"Paro");
	   System.out.println(a1);
	   
	   a1.remove(4);
	   System.out.println(a1);
	   
	   a1.set(0, "KamlaBai"); //data is Overridden
	   System.out.println(a1);	   
}
}
