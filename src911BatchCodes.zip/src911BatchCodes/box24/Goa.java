package box24;

import java.util.ArrayList;

public class Goa {
   public static void main(String[] args) {
	
	   ArrayList<Object> a1 = new ArrayList<Object>();
	   a1.add("Club");
	   a1.add(29);
	   a1.add(29);
	   a1.add(78.54);
	   a1.add(true);
	   a1.add(9876543L);
	   
	   System.out.println(a1);
	   System.out.println(a1.size());
	   System.out.println(a1.contains(29)); //true
	   System.out.println(a1.contains("Club")); //true
	   System.out.println(a1.contains("Daru")); //false
	   
	   a1.remove(1);
	   System.out.println(a1);
	   a1.remove(3);
	   System.out.println(a1);
	   
	   System.out.println(a1.isEmpty()); //false
	   System.out.println("------");
	   
	   a1.clear();
	   System.out.println(a1);
	   System.out.println(a1.isEmpty()); //true
	   
	   a1.add("Beach");
	   System.out.println(a1);
	   
}
}
