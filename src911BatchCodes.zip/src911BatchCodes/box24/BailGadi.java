package box24;

import java.util.ArrayList;

public class BailGadi {
   public static void main(String[] args) {
	
    ArrayList<String> a1 = new ArrayList<String>(500);
    a1.add("Valoo");
    a1.add("Cement");
    a1.add("Cement");
    a1.add("Steel");
    a1.add("Mistri");
    a1.add("Vita");
    a1.add("H2O");
    a1.add("Tiles");
    a1.add("Paise");
    a1.add("Land");
    a1.add("Khadi");
      
    System.out.println(a1); 
    //[Valoo, Cement, Cement, Steel, Mistri, Vita, H2O, Tiles, Paise, Land, Khadi]   
}
}
