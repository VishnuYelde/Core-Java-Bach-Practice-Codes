package box24;

import java.util.ArrayList;

public class Kirmada {
  public static void main(String[] args) {
	
	  ArrayList<String> bag1 = new ArrayList<String>();
	  bag1.add("Kaliya");
	  bag1.add("Urfi");
	  bag1.add("Orry");
	  bag1.add("Rakhi");
	  System.out.println(bag1);//[Kaliya, Urfi, Orry, Rakhi]
	  
	  System.out.println("--------");
	  ArrayList<Object> bag2 = new ArrayList<Object>();
	  bag2.add(786);
	  bag2.add(55.55);
	  System.out.println(bag2); //[786, 55.55]
	  
	  bag2.addAll(bag1);
	  System.out.println(bag2); //[786, 55.55, Kaliya, Urfi, Orry, Rakhi]
	  bag2.remove(2);
	  System.out.println(bag2);
	  
	  bag2.add(2,"KaranJ"); //adding Object in Between
	  System.out.println(bag2);
	  
	  System.out.println(bag2.containsAll(bag1)); //false //Kaliya is missing
	  
	  System.out.println(bag2.removeAll(bag1)); //true
	  //removing bag1 objects from bag2
	  System.out.println(bag2); //[786, 55.55, KaranJ]
	  
}
}
