package box24;

public class ZigZag {
  public static void main(String[] args) {
	
	  int a = 45;
	  System.out.println(a);
	  
	  Integer i1 = new Integer(180);
	  Integer i2 = 250;
	  System.out.println(i1); //180
	  System.out.println(i1.toString()); //180
	  //toString() is overridden in all Wrapper classes and String class
	  System.out.println(i2); //250
	  
	  Character c1 = 'A';
	  Character c2 = new  Character('Z');
	  System.out.println(c1); //A
	  System.out.println(c2); //Z
	  
	  System.out.println("--------");
	  
	  Object o1 = 'A';       //Upcasting 
	  Object o2= "Hritik";
	  Object o3 = true;
	  Object o4 = 600;
	  
	  System.out.println(o1+"   "+o2+"  "+o3+"  "+o4);
	  
	  
	  int m1 = 900;
	  Integer m2 = m1;
	  System.out.println(m2); //900   //Boxing
	  //wrapper class format , non-primitive
	  
	  Double d1 = new Double(45.45);
	  double d2 = d1;
	  System.out.println(d2); //45.45
	  //Autounboxing
	  
	  
	  
}
}
