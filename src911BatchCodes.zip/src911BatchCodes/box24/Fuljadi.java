package box24;

import java.util.ArrayList;

public class Fuljadi {
   public static void main(String[] args) {
	
	   ArrayList<Object> a1 = new ArrayList<Object>();
	   a1.add("Vishnu");
	   a1.add(420);
	   a1.add(true);
	   a1.add(786);
	   a1.add(900);
	   a1.add(55.55);
	   a1.add('A');
	   
	   System.out.println(a1); 
	   //[Vishnu, 420, true, 786, 900, 55.55, A]
	ArrayList<Object> a2 = new ArrayList<Object>();
	   
	   for(Object ob : a1) {   
		   if(ob instanceof Integer) {
			  Integer i1 = (Integer)ob; //Downcasting
			 a2.add(i1);  
		   }
	   }
	   System.out.println("--------");
	   System.out.println(a2);
	  
}
}
