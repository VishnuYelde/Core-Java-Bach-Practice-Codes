package box24;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Vector;

public class Fataka {
     public static void main(String[] args) {
		
    	 Vector<Integer> v1 = new Vector<Integer>();
    	 v1.add(20);
    	 v1.add(71);
    	 v1.add(69);
    	 v1.add(40);
    	 v1.add(40);
    	 v1.add(90);
    	 v1.add(45);
    	 v1.add(18);
    	 v1.add(63);
    	 v1.add(55);
    	 
    	 System.out.println(v1);
    	 
    	 Collections.sort(v1); //sorting Ascending Order
    	 
    	 System.out.println(v1); //[18, 20, 40, 45, 55, 63, 69, 71, 90]
    	 
    	 System.out.println("------");
    	 //Ascending Order
    	 for(Integer i1 : v1) {
    		System.out.println(i1); 
    	 }
    	 
    	 System.out.println("----------");
    	 //Descending order
    	 Collections.reverse(v1);
    	 
    	 for(Integer i1 : v1) {
     		System.out.println(i1); 
     	 }
    	 
    	 ArrayList<Object> a1 = new ArrayList<Object>();
    	 a1.add("Vishnu");
    	 a1.add(true);
    	 a1.add(600);
    	 a1.add(77.55);
    	 a1.add(770);
    	 a1.add(350);
    	 a1.add(420);
    	 
    	 
    	 for(Object i : a1) {
    		 System.out.println(i);
    	 } 	 
    	 
	}
}
