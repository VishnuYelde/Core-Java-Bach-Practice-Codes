package box24;

import java.util.ArrayList;

public class Money {
  public static void main(String[] args) {
	
   ArrayList<Object> a1 = new ArrayList<Object>();
   a1.add("ChotaBheem");
   a1.add("Tom&Jerry");
   a1.add("ShinChan");
   a1.add("Doremon");
   System.out.println(a1);
   //[ChotaBheem, Tom&Jerry, ShinChan, Doremon]
   
   System.out.println("-------");
                               //adding one collection in another
   ArrayList<Object> a2 = new ArrayList<Object>(a1);
   a2.add("Ben10");
   a2.add("MickeyMouse");
           // a2.addAll(a1);
   a2.add("Pokemon");
 
   System.out.println(a2);
   //[ChotaBheem, Tom&Jerry, ShinChan, Doremon, Ben10, MickeyMouse, Pokemon]
}
}
