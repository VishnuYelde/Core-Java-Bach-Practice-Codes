package box24;

import java.util.LinkedList;

public class GhodaGadi {
   public static void main(String[] args) {
	
	   LinkedList<Object> l1 = new LinkedList<Object>();
	   l1.add(500);  //Object o1 = new Integer(500);
	   l1.add(false); 
	            //Object o2 = new Boolean(false);
	   l1.add(98765432L);
	   
	   System.out.println(l1);
	    //[500, false, 98765432]
	   	   
}
}
