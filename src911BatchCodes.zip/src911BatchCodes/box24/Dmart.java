package box24;

import java.util.ArrayList;

public class Dmart {
  public static void main(String[] args) {
	System.out.println("Dmart start");
	
	ArrayList<Object> a1 = new ArrayList<Object>();
	a1.add("Aloo");
	a1.add("Sugar");
	a1.add("Ata");
	a1.add("Ata");
	a1.add(700);
	a1.add(88.88);
	a1.add("Santoor");
	a1.add("SurfExcel");
	a1.add("Maggi");
	a1.add("Vim");
	a1.add("Tomato");
	a1.add("Eggs");
	
	System.out.println(a1.size()); //12
	System.out.println(a1);	
	System.out.println(a1.indexOf("Santoor")); //6
	System.out.println(a1.indexOf("Aloo")); //0
	System.out.println(a1.indexOf("Harpik")); //-1
	System.out.println(a1.indexOf("Ata")); //2
	System.out.println(a1.lastIndexOf("Ata")); //3
	
	System.out.println(a1.get(1)); //Sugar
	System.out.println(a1.get(11)); //Eggs
	
	//System.out.println(a1.get(15)); //IndexOutOfBoundsException
	System.out.println(a1); //[Aloo, Sugar, Ata, Ata, 700, 88.88, Santoor, SurfExcel, Maggi, Vim, Tomato, Eggs]
	a1.add(1,"TataSalt");
	System.out.println(a1); //[Aloo, TataSalt, Sugar, Ata, Ata, 700, 88.88, Santoor, SurfExcel, Maggi, Vim, Tomato, Eggs]
	a1.add(3,false);
	System.out.println(a1); //[Aloo, TataSalt, Sugar, false, Ata, Ata, 700, 88.88, Santoor, SurfExcel, Maggi, Vim, Tomato, Eggs]
	
	System.out.println(a1.size()); //14
	System.out.println("---------");
	a1.set(1, "PinkSalt");
	System.out.println(a1);
	
	System.out.println("Dmart End");
}
}
