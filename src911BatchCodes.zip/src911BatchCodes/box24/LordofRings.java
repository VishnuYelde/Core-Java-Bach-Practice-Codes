package box24;

import java.util.ArrayList;

public class LordofRings {
   public static void main(String[] args) {
	
	 //  int[] arr = {23,45,67,"Aryan",98,56,351,21,42};
	   
	   ArrayList a1 = new ArrayList();
	   a1.add("Vishnu"); 
	   a1.add(22);
	   a1.add('M');
	   a1.add(9876549876L);
	   a1.add(true);
	   
	   System.out.println(a1);
	   
	  
	  // System.out.println(i1);
}
}
