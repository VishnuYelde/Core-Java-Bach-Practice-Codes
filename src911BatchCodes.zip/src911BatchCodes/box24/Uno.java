package box24;

import java.util.Collections;
import java.util.LinkedList;

public class Uno {
   public static void main(String[] args) {
	
	   LinkedList<String> l1 = new LinkedList<String>();
	   l1.add("GulabJamun");
	   l1.add("KajuKatli");
	   l1.add("Chakli");
	   l1.add("Chivda");
	   l1.add("Ladoo");
	   l1.add("Karanji");
	   l1.add("ShankarPali");
	   l1.add("Anarse");
	   l1.add("Shev");
	   
	   System.out.println(l1);
	   //[GulabJamun, KajuKatli, Chakli, Chivda, Ladoo, Karanji, ShankarPali, Anarse, Shev]
	   
//	   for(Object ob : l1) {
//		   System.out.println(ob);
//	   }
	   //or
	   for(String s1 : l1) {
		   System.out.println(s1);
	   }
	   
	   System.out.println("------");
	   
	   Collections.reverse(l1);
	   System.out.println(l1);
	   
//	   for(String s1 : l1) {
//		   System.out.println(s1);
//	   }
	  
}
}
