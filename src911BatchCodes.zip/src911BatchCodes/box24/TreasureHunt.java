package box24;

import java.util.LinkedList;

public class TreasureHunt {
   public static void main(String[] args) {
	
	  LinkedList<Object> l1 = new LinkedList<Object>();
	  l1.add("Mango");
	  l1.add(333);
	  l1.add("Apple");
	  l1.add("Batata");
	  
	  System.out.println(l1); //[Mango, 333, Apple, Batata]
	  l1.add(2,"Rose");
	  System.out.println(l1);
	  //[Mango, 333, Rose, Apple, Batata]
}
}
