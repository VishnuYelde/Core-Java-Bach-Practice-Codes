package box24;

import java.util.Collections;

public class Electronics {
  public static void main(String[] args) {
	
	  int[] arr = {23,56,87,56,45,23,98,57,12,42,16,72};
	  
	  //normal for loop
	  for(int i=0;  i<arr.length; i++) {
		  System.out.println(arr[i]);
	  }
	  
	  System.out.println("------");
	  
	  //for-each loop /Enhanced for loop
	  for(int i1 : arr) {
		  System.out.println(i1);
	  }
	  
//	  //reverse of Array
//	  for(int i=arr.length-1;  i>=0; i--) {
//		  System.out.print(arr[i]+" ");
//	  }
	  
}
}
