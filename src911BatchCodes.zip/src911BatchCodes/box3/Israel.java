package box3;

public class Israel {
	public static void main(String[] args) {

		int i = 20;
		while (i <= 50) {
			if (i % 5 == 0) {
				System.out.println(i);
			}
			i++;
		}

	}
}
