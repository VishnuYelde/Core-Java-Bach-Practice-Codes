package box3;

public class Chandramukhi {
  public static void main(String[] args) {
	
	  int a = 100;
	  int b = 250; 
	  
	  a=a+b;
	  b=a-b;
	  a=a-b;
	  
	  System.out.println("A value is "+a);
	  System.out.println("B value is "+b);
}
}
