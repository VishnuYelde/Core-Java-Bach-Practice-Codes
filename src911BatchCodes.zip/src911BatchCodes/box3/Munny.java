package box3;

public class Munny {
  public static void main(String[] args) {
	
	  int num = 45754;
	  int temp =num;
	  int rev = 0;
	  
	  while(num != 0) 
	  {
		int rem = num%10;
		  rev = (rev*10)+rem;
		  num=num/10;
	  }
	  
	  System.out.println(rev);  
	  System.out.println("num is "+num); //0
	  
	 System.out.println("------");
	 
	 if(rev==temp) {
		 System.out.println(temp+" is Palindrone");
	 }else {
		 System.out.println(temp+" is Not Palindrome");
	 }
}
}
