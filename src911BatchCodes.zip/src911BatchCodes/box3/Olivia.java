package box3;

public class Olivia {
  public static void main(String[] args) {
	
	  int num = 5;
	  int fact =1;
	  
	  for(int i=num; i>=1; i--) {
		  fact*=i;
	  }
	  System.out.println("Factorial of "+num+" is :"+fact);
}
}
