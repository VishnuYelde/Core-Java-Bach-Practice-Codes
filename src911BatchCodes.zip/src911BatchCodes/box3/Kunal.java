package box3;

public class Kunal {
  public static void main(String[] args) {
	
	  int a = 72;
	  int b= 45;
	  
	  int temp = a;
	       a= b;
	       b= temp;
	       
	       System.out.println("A value is "+a);
	       System.out.println("B value is "+b);
}
}
