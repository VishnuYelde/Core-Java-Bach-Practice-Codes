package box3;

public class Holiday {
public static void main(String[] args) {
	
	String str = "Dheeraj";
	String rev = "";
	
	for(int i=0; i<str.length(); i++) {
		rev = str.charAt(i)+rev;
	}
	
	System.out.println(rev);
}
}
