package box3;

public class Thakre {
  public static void main(String[] args) {
	
	  int num = 10;
	  int sum = 0;
	  
	  for(int i=1; i<=num; i++) {
		  sum+=i;
	  }
	  System.out.println("Sum is "+sum);
}
}
