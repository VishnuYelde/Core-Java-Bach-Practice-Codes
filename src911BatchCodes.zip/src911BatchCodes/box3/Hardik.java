package box3;

public class Hardik {
  public static void main(String[] args) {
System.out.println("Main start");	
	  int i=1;
	  
	  do {
		  System.out.println(i);
		  i++;
	  }while("Hardik"=="CSK");
	  
	  System.out.println("Main End");	
}
}
