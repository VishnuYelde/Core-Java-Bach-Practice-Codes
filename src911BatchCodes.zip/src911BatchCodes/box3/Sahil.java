package box3;

public class Sahil {
  public static void main(String[] args) {
	
	  String str = "Dheeraj";
	  String rev = "";
	  
	  for(int i=0; i<str.length(); i++) {
		  rev = str.charAt(i)+rev;
	  }
	  
	  System.out.println(rev);
	   
	  
	/*  System.out.println(str.charAt(0)); //D
	  System.out.println(str.charAt(1)); //h
	  System.out.println("-------");
	  System.out.println(str.length()); //7 */
}
}
