package box8;

public class Saiyaara {
   public static void main(String[] args) {
	
	   System.out.println(Ashiqui.a);
	   Ashiqui.sing();
}
}
