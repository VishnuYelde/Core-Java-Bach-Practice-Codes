package box8;



public class VadaPav {
   public static void main(String[] args) {
	System.out.println("VadaPav start");
	
	System.out.println("VadaPav End");
}
}
