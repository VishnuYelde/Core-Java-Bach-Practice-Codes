package box8;

public class Barfi {
   
	static int x = 50;  //static global variable
	       int y = 80;  //non-static global variable
	       
	 static void jump() {  //static method
		 System.out.println("Jump...");
	 }
	 
	     void dance() {  //non static method
	    	 System.out.println("Lavani..");
	     }
}
