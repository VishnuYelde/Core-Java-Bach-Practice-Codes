package box8;

class MisalPav{
	 public static void main(String[] args) {
			System.out.println("M start");
			
			System.out.println("M End");
		} 
}

class Kachori{
	 public static void main(String[] args) {
			System.out.println("K start");
			
			System.out.println("K End");
		} 
}

class Samosa
{
	 public static void main(String[] args) {
			System.out.println("Samosa start");
			
			System.out.println("Samosa End");
		} 
	
}

public class Chutney {
  public static void main(String[] args) {
	  System.out.println("Chutney start");
	  
	  System.out.println("Chutney End");
}
}
