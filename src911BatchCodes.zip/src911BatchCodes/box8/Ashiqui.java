package box8;

public class Ashiqui {
   
	static int a = 10; //static global var
	
	static void sing() {  //static method
	   System.out.println("Dhere Dhere..");
	}
}
