package box20;

class Thane{
	int x = 100;
	void study() {
		System.out.println("Qspiders me Study");
	}
}

class Maharashtra{
	
	static Thane t1 = new Thane();
	
	int i = 200;
	
	void travel() {
		System.out.println("Seawoods");
	}
}

class India {
	
	static Maharashtra m1 = new Maharashtra();
	
	int p = 500;
	 
	void festivals() {
		System.out.println("Ganesh Chaturthi");
	}
}

public class Asia {
   public static void main(String[] args) {
	
	   India i1 = new India();
	   System.out.println(India.m1.t1.x);
	   India.m1.t1.study();
	   
	   System.out.println(India.m1.i);
	   India.m1.travel();
	   
   }
	
}
