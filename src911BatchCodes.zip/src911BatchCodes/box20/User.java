package box20;

public class User {
  public static void main(String[] args) {
	
	  Mobile m1 = new Mobile();
	  System.out.println(m1.x);
	  m1.games();
	  System.out.println(m1.b1.i);
	  m1.b1.capacity();
	  Mobile.b1.capacity();
	  
	  System.out.println();
	  System.out.println('A');
	  System.out.println(657);
	  System.out.println(2345678876L);
	  System.out.println(45.56d);
	  System.out.println(45.54f);
	  System.out.println(true);
	  
	  //System --> Builtin final Class 
	  //out --> static refvar of PrintStream class
	  //println--> Overloaded Method of PrintStream class
}
}
