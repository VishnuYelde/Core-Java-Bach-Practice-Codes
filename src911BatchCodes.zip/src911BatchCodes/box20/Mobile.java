package box20;

public class Mobile {
	
	static Battery b1 = new Battery(); //object
	
	int x = 70;
	
	void games() {
		System.out.println("PuB G..");
	}
}
