package box20;

class Dosa{   //this() calling statement
	
	Dosa(){
		this(50,80);
		System.out.println("Sada Dosa");
	}
	
	Dosa(int a){
		System.out.println(" 1 int masala Dosa");
	}
	
	Dosa(int m , int n){
		this(35);
		System.out.println(" Paneer Dosa");
	}	
}

public class Idli {
  public static void main(String[] args) {
	
	  Dosa d1 = new Dosa();
	  
}
}
