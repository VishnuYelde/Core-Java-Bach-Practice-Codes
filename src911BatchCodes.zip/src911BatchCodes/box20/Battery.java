package box20;

public class Battery {
   
	int i = 6000;
	
	void capacity() {  
		System.out.println("5000 mah Battery");
	}
	
	void capacity(int a) {  
		System.out.println("1 int para method");
	}
}
