package box19;

public interface ATM1 {
 
	public abstract void deposit(int amt1);
	                void withdraw(int amt2);
	                void checkBal();
}
