package box19;

public interface ATM2 {

	public abstract void deposit(int amt1);
    void withdraw(int amt2);
    void checkBal();
}
