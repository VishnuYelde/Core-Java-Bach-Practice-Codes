package box19;

public class HDFCUSer {
   public static void main(String[] args) {
	System.out.println("HDFC start");
	
	ATM1 u1 = new Bank();  //Upcasting
	u1.checkBal();
	u1.deposit(25000);
	u1.withdraw(7000);
	u1.checkBal();
	
	System.out.println("----------");
	
	ATM2 u2 = new Bank(); //Upcasting
	u2.deposit(6000);
    u2.withdraw(1500);	
    u2.checkBal();
    
    System.out.println("------------");
    
    ATM1 u3 = new Bank(); //Upcasting
    u3.checkBal();
    u3.withdraw(2000);
    u3.deposit(-4000);
    u3.deposit(9000);
    u3.withdraw(5000);
    u3.checkBal();
    
	System.out.println("HDFC End");
}
}
