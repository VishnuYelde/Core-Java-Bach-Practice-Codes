package box19;

public class Bank implements ATM1,ATM2, ATM3 
{
    int totalBal = 0;   //non-static var
	
	@Override
	public void deposit(int amt1) {
		if(amt1 > 0) {
			totalBal +=amt1;  //totalBal = totalBal+amt1;
			System.out.println(amt1+" Deposited Successfully");
		}else {
			System.out.println("Enter Valid Deposit Amount");
		}
	}

	@Override
	public void withdraw(int amt2) {
		if(amt2 <= totalBal) {
			totalBal -=amt2; //totalBal =totalBal -amt2
			System.out.println(amt2+ " Withdraw Successfully");
		}else {
			System.out.println("Tera Bap Chodh ke gaya Tha ke Tere Ma");
		}
	}

	@Override
	public void checkBal() {
		System.out.println("Total Available Balance is "+ totalBal );
	}
}
