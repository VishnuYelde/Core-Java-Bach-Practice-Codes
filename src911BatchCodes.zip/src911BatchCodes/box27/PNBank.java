package box27;

class Account{
	              //half object
	private static Account obj; // default value is null
	
	  private Account() {
			System.out.println("Account Created..");		
	   } 
	
	  public static void createAccount(){ 
		  if(obj==null) {
		   obj= new Account(); //Account class half object 
		 } else {
			 System.out.println("Account Already exists");
		 }
	  }
}

public class PNBank {
  public static void main(String[] args) {
	
	 // Account obj = new Account(); //we cannot create objects as it is Private
	  
	 Account.createAccount();
	 Account.createAccount();
	 Account.createAccount();
	 
	 //Comparable
}
}
