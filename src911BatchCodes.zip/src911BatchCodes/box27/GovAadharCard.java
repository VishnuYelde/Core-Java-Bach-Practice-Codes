package box27;

import java.util.Set;
import java.util.TreeMap;

public class GovAadharCard {
   
   public static void main(String[] args) {
	
	   Person p1 = new Person("Suraj",21,'M',"10 October");
	   Person p2 = new Person("Vishal",22,'M',"23 August");
	   Person p3 = new Person("Sandeep",24,'M',"16 October");
	   Person p4 = new Person("Prajwal",21,'M',"9th Feb");
	   Person p5 = new Person("yash",21,'M',"14Th Feb");
	   
	   TreeMap<Integer,Person > t1 = new TreeMap<Integer,Person>();
	   t1.put(200, p1);
	   t1.put(150, new Person("Vishal",22,'M',"23 August"));
	   t1.put(450, p3);
	   t1.put(600, p4);
	   t1.put(50, p5);
	   
	   Set<Integer> s1 = t1.keySet();
	   
	   for(Integer i : s1) {
		  System.out.println(i+" --> "+t1.get(i)); 
	   }
	   
	   System.out.println("----------");
	   
	   System.out.println("The Data is "+t1.entrySet());
}
}
