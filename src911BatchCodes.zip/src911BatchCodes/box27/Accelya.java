package box27;

import java.util.TreeSet;

class Employee implements Comparable<Employee>{

	String name;
	int empid;
	double sal;
	
	public Employee(String name, int empid, double sal) {
		this.name = name;
		this.empid = empid;
		this.sal = sal;
	}

    public String toString() {
    	return "Employee Name "+name+" Empid :"+empid+"  Salary :"+sal;
    }

//	@Override   //sorting based on empid
//	public int compareTo(Employee e) {
//		return this.empid-e.empid;
//	}	
    
//    @Override    //sorting based on Salary
//	public int compareTo(Employee e) {
//		return (int)this.sal-(int)e.sal;  //or return this.sal.compareTo(e.sal);
//	}	
	  
  @Override    //sorting based on name
	public int compareTo(Employee e) {
		return this.name.compareTo(e.name);
	}	
}

public class Accelya {
  public static void main(String[] args) {
	
	  Employee e1 = new Employee("Hritik", 550, 90000);
	  Employee e2 = new Employee("Rahul", 450, 93000);
	  Employee e3 = new Employee("Sandeep", 600, 85000);
	  Employee e4 = new Employee("Mayur", 420, 87000);
	  
	  TreeSet<Employee> t1 = new TreeSet<Employee>();
	  t1.add(e1);
	  t1.add(e2);
	  t1.add(e3);
	  t1.add(e4);
	 
	  
	  for(Employee m : t1) {
		  System.out.println(m);
	  }
}
}
