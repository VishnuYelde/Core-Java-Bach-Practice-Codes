package box27;

public class Person {

	String name;
	int age;
	char gen;
	String dob;
	
	public Person(String name, int age, char gen, String dob) {
		this.name = name;
		this.age = age;
		this.gen = gen;
		this.dob = dob;
	}
	
	@Override
	public String toString() {
		return "Name is :"+name+" Age is "+age+" Gender is "+gen+" DOB is "+dob;
		
	}
}
