package box15;

public class MuthuSir {
	
	final int m;
	 
	MuthuSir(){
		m=60;
	}
	
	
  public static void main(String[] args) {
	
	final double pi = 3.142;	  
	       //pi=8.547;  
	  System.out.println(pi);
	
	final  int a;
             	a=90;
	System.out.println(a);
	  
}
}
