package box15;

class Pitaji{
	
	void land() {
	  System.out.println("100 Acre Land");	
	}
}

class Ravi extends Pitaji{
	
	@Override
	void land() {
		  System.out.println("80 Acre Land");	
		}
	
     void land(double d) {
    	 System.out.println("5 acre near Airport..");
     }     
     /*Can we Overload and Override at the Same time? 
      Ans : Yes */
}

public class Maqsad {
  public static void main(String[] args) {
	
	  Ravi r1 = new Ravi();
	  r1.land();  //80 Acre Land
	  r1.land(55.55); //5 acre near Airport..
}
}
