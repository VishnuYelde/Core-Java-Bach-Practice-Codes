package box15;

class Father{
	
	 void house() {
		System.out.println("2 Floor Building");
	}
	  
}

class Rahul extends Father{
	
	@Override
	 void house() {
		System.out.println("4 floor Building Rop Top Garden");
		
	}

}

public class BhabiJiGharPehai {
  public static void main(String[] args) {
	
	  Rahul r1 = new Rahul();
	  r1.house(); //4 floor Builsding Rop Top Garden
	  
	  System.out.println("--------");
	  
	  Father f1 = new Father();
	  f1.house(); //2 Floor Building
}
}
