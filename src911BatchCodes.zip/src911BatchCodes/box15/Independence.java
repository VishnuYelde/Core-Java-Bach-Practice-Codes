package box15;

class Champaklal{
	
	Champaklal(char ch){
		System.out.println("Inside Champaklal Constructor");
	}
}

class Jhetalal extends Champaklal{
	
	Jhetalal(int a, int b){
		super('A');
		System.out.println("Inside Jhetalal Constructor");
	}
}

class Tappu extends Jhetalal{
	
	Tappu(String s){
		super(30,70);
		System.out.println("Inside Tappu Constructor");
	}
}

public class Independence {
   public static void main(String[] args) {
   System.out.println("I Start");
   
	   Tappu t1 = new Tappu("Cycle");
	   
	   System.out.println("I End");
	   
}
}
