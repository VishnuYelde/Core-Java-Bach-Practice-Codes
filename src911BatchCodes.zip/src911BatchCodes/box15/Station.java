package box15;

public class Station {
  public static void main(String[] args) {
	
	  double d = 50; //widening
	  System.out.println(d);
	  
	  int a = (int)55.55;  //narrowing //data loss 
	  System.out.println(a);
	  
	  
	  float f1 = 98765432L;  //Widening
	  System.out.println(f1); //9.876543E7
	  
	  double l1 = 4676543456764455466445544D;
	  System.out.println(l1); //4.6765434567644556E24
	  
	  System.out.println("---------");
	  
	  int i1 = Integer.MAX_VALUE;
	  int i2 = Integer.MIN_VALUE;
	  System.out.println(i1); //2147483647
	  System.out.println(i2); //-2147483648
	  
	  int m = 2147483647;
	  System.out.println(m); //2147483647
	  //no one drop extra
	  
	  System.out.println("------");
	  double k = Double.MAX_VALUE;
	  double n = Double.MIN_VALUE;
	  System.out.println(k); //1.7976931348623157E308
	  System.out.println(n); //4.9E-324
	  
	  double t = 2345678908765456789876543547688976543356789D;
	  System.out.println(t); //2.345678908765457E42
	  
	  System.out.println("---------");
	  
	  byte b1 = Byte.MAX_VALUE;
	  byte b2 = Byte.MIN_VALUE;
	  System.out.println(b1); //127
	  System.out.println(b2); //-128
}
}
