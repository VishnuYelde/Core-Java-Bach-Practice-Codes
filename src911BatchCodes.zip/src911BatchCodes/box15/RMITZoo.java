package box15;

class Animal{
	
	void eat() {
		System.out.println("Animals eat food");
	}
	
	void drink() {
		System.out.println("Drink H2O");
	}
	
	void sleep() {
		System.out.println("Sleep at Night");
	}
	
	void breathe() {
		System.out.println("Breathe O2");
	}
	
	void sound() {
		System.out.println("Animal Makes sound");
	}
}


class Dog extends Animal{
	
	@Override
	void sound() {
		System.out.println("Bhaww...Bhawww");
	}
	
}

class Cat extends Animal{
	
	@Override
	void sound() {
		System.out.println("Meoww..Meoww..");
	}
	
}

class Snake extends Animal{
	
	@Override
	void sound() {
		System.out.println("Hiss Hiss");
	}
}


public class RMITZoo {
  public static void main(String[] args) {
	System.out.println("Main start");
	
	
	Animal a1 = new Snake();
	a1.eat();
	a1.drink();
	a1.sound();
	
	System.out.println("------");
	
	
	
	
	
/*	Dog d1 = new Dog();
	d1.eat(); //Animals eat food
	d1.breathe(); //Breathe O2
	d1.sound(); //Bhaww...Bhawww
	
	System.out.println("--------");
	
	Cat c1 = new Cat();
	c1.drink(); //Drink H2O
	c1.eat(); //Animals eat food
	c1.sound(); //Meoww..Meoww.. */
		
	System.out.println("Main End");
}
}
