package box15;

class Father1{
	
	int a = 100;
	void work() {
		System.out.println("Hard working..");
	}
}

class Son extends Father1{
	int i = 50;
	 void study() {
		 System.out.println("Studing..");
	 }
}

public class LateCommer {
  public static void main(String[] args) {
	
	  Father1 f1 = new Son(); //Upcasting
	  System.out.println(f1.a);
	  f1.work();
	  //System.out.println(f1.i);
	  //f1.study();
	  
	  System.out.println("-------");
	  
	  Son s1 = (Son)f1;  //Downcasting
	  System.out.println(s1.a);
	  s1.work();
	  System.out.println(s1.i);
	  s1.study();  	  
}
}
