package box11Access;



       //diff class same package
public class Annabelle {
  public static void main(String[] args) {
	System.out.println("Annabelle start");
	
	Conjuring c1 = new Conjuring(); //Object
	System.out.println(c1.a);
	System.out.println(c1.b);
	System.out.println(c1.c);
	//System.out.println(c1.d); //CTE Private
	
	c1.demo1();
	c1.demo2();
	c1.demo3();
	//c1.demo4(); //CTE Private
	
	System.out.println("Annabelle End");
}
}
