package box21;

public class Spider {
   public static void main(String[] args) {
	//Checked Exception
	   for(int r=1; r<=5; r++)
	   {
		   for(int c=1; c<=5; c++) {
			   System.out.print("* ");
			  
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					
					e.printStackTrace();
				}
			
		   }
		   System.out.println();
	   }
}
}
