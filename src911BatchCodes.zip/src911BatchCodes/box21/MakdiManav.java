package box21;

public class MakdiManav {
	//unchecked Exception
	String s = "Vishal";
	
   public static void main(String[] args) {
	System.out.println("Main start");
	
	MakdiManav  m1 = null;
	     //m1=new MakdiManav();
	  try {    
	System.out.println(m1.s);
	  }catch(NullPointerException n1) {
		  System.out.println("Nalle Kuch nahi hai waha pe..");
	  }
	
	System.out.println("Main End");
	   
}
}
