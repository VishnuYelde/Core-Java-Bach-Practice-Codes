package box21;

public class Nepal extends Object{
	   //magic code
	public static void jadu() throws InterruptedException ,ArithmeticException{
		
		for(int i=1; i<=10; i++) {
			System.out.println(i);
				Thread.sleep(200);
			} 
		}	
	
   public static void main(String[] args) {
	System.out.println("Main start");
	try {
	jadu();	
	}catch(InterruptedException i1) {
		System.out.println("Handled...");
	}
	System.out.println("Main End");
}
   
 
}
