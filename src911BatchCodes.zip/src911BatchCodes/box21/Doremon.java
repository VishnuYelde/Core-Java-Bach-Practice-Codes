package box21;

import java.util.Scanner;

public class Doremon {
   public static void main(String[] args) {
	System.out.println("Main start");
	  Scanner sc = new Scanner(System.in);
	  
	  String str = "Satyam";
	  
	  System.out.println("Enter Index number");
	  int n = sc.nextInt();	  
	  
	  try {
	  System.out.println(str.charAt(n));
	  }catch(StringIndexOutOfBoundsException s1) {
		System.out.println("Index out of bound hai..");  
	  }finally {
		  System.out.println("Inside finally block");
		  sc.close();
	  }
	  System.out.println("Main End");
}
}
