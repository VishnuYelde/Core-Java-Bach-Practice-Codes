package box21;

import java.util.Scanner;

public class KunalKeSupriya {
   public static void main(String[] args) {
	System.out.println("Main start");
	
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter 1st Num");
	int a = sc.nextInt();
	System.out.println("Enter 2nd Num");
	int b = sc.nextInt();

	try {
	System.out.println(a/b);
	}catch(ArithmeticException a1 ){
		System.out.println("Gadha Zero se Divide Mat Kar");
	}
	System.out.println("Helooo..");
	System.out.println("Main End");
}
}
