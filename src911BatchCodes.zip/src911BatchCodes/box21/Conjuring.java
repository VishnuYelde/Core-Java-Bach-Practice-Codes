package box21;

public interface Conjuring {
   
	void jump(); 
	
	default void dance() {
		
	}
}
