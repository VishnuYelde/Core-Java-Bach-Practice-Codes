package box21;

public class Satyam {
	int a = 200;
	static int pid= 500;
	
	@Override
	public String toString() {
		return "PID"+pid++;
	}
	
  public static void main(String[] args) {
	
	  Satyam s1 = new Satyam();
	  System.out.println(s1.a);
	  System.out.println(s1);
	  System.out.println(s1.toString());
	  
	  Satyam s2 = new Satyam();
	  System.out.println(s2);
	  
	  Satyam s3 = new Satyam();
	  System.out.println(s3);
	  
}
}
