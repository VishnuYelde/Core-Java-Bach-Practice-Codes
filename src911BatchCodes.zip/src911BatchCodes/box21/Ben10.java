package box21;

public class Ben10 {
  public static void main(String[] args) {
	System.out.println("Main start");
	
	
	
	  System.out.println(65/0);
	  
	  System.out.println("Main End");
}
}
