package box14;

public class Shetty {
	
	void add() {  //non-para method
		System.out.println(700);
	}
	
	void add(int a, int b) {  //2 int ,int-para method
		System.out.println(a+b);
	}
	
	void add(char ch, int j) {  //2 char ,int-para method
		System.out.println(ch+j);
	}
	
	
  public static void main(String[] args) {
	System.out.println("Main start");
	
	Shetty s1 = new Shetty();
	s1.add();
	s1.add(60,40);
	s1.add('A',200);
	
	System.out.println("Main start");
}
}
