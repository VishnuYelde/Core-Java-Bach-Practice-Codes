package box14;

public class Sudarshan {    //MEthod Overloading
	
	static void dance() { 
		System.out.println("Lavani");
	}
	
	static void dance(int a) { 
		System.out.println("Hip Hop");
	}
	
	static void dance(String s) { 
		System.out.println("Kathak");
	}
	
	static void dance(int i, int j) { 
		System.out.println("Bhangra");
	}
	
	static void dance(double i, int j) { 
		System.out.println("Break Dance");
	}
	
	static void dance( int x , double y) { 
		System.out.println("Pole Dance");
	}

	
  public static void main(String[] args) {
	System.out.println("Main start");
	
	Sudarshan.dance(); //Lavani
	dance(); //Lavani
	dance(50); // Hip Hop
	dance(45,80); //Bhangra
	dance(56, 7.5);  //Pole Dance
	
	
	System.out.println("Main End");
}
}
