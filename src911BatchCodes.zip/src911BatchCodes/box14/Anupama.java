package box14;

public class Anupama {
  
	public static void main(char ch) {
		System.out.println("Main char start");
		
		System.out.println("Main char End");
	}
	
	public static void main(String[] args) {
		System.out.println("Main String[] start");
		
		main('A');
		System.out.println("-----");
		main(60);
		System.out.println("Main String[] End");
	}
	
	public static void main(int a) {
		System.out.println("Main int start");
		
		System.out.println("Main int End");
	}
}
