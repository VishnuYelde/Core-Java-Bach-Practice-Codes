package box14;

class Person{     //Constructor Chaining
	
	String name;
	int age;
	char gen;
	
	public Person(String name, int age, char gen) {	
		this.name = name;
		this.age = age;
		this.gen = gen;
		System.out.println("Person class Const");
	}
}

class Student extends Person{
	
	int rollno;
	double per;
	String college;
	
	public Student(String name, int age, char gen, 
			        int rollno, double per, String college) {
		super(name, age, gen);
		this.rollno = rollno;
		this.per = per;
		this.college = college;
		System.out.println("Student class Const");
	}		
}

class Employee extends Person{
	
	 int empid;
	 double sal;
	 String job;
	 
	 public Employee(String name, int age, char gen, 
			            int empid, double sal, String job) {
		super(name, age, gen);
		this.empid = empid;
		this.sal = sal;
		this.job = job;
		System.out.println("Employee class Const");
	 }	 
}

public class Burari {

	public static void main(String[] args) {
	System.out.println("Main start");	
	
	 Student s1 = new  Student("Adnan",21,'M',25,92.54,"DattaMegheCollege"); //Object
	  System.out.println(s1.name);
	  System.out.println(s1.per);
	  
	  System.out.println("-----------------");
	  
	  Employee e1 = new Employee("Rahul",22,'M',420,50000,"SD");  //Object
	  System.out.println(e1.name);
	  System.out.println(e1.empid);
	  
	  /*"A phenomenon of running more than one constructor to 
	   initialize the attributes 
          of an object is called as Constructor Chaining"*/
	
	System.out.println("Main End");	   
	}
}
