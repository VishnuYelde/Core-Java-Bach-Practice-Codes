package box5;

public class Ravan {
   public static void main(String[] args) {
	
	   int rn=11;
	   int cn =11;
	   
	   for(int r=1;r<=rn;r++) {
		   for(int c=1; c<=cn; c++) {
			   
			   if( r==(rn/2)+1 && c==(cn/2)+1){
				  System.out.print("💖 ");   
			   }  else if(r==1 || c==1 || r==rn|| c==cn
					    || r==c){
				   System.out.print("* ");
			   }else {
				   System.out.print("  ");
			   }
		   }
		   System.out.println();
	   }
	   
}
}
