package box5;

public class Bakasur {
  public static void main(String[] args) {
	int rn = 17;
	int cn = 17;
	
	for(int r=1; r<=rn; r++)
	{
		for(int c=1; c<=cn; c++)
		{
			if(r==(rn/2)+1 && c==(cn/2)+1) {
				System.out.print("💖 ");
			}else if(r==1 || c==1 || r==rn|| c==cn
				   || r==(rn/2)+1 || c==(cn/2)+1
				   || r==c || r+c==rn+1) {
			   System.out.print("* ");
		   }else {
			   System.out.print("0 ");
		   }
		  
		   
		}
		System.out.println();
	}
	
}
}
