package box5;

import java.util.Scanner;

public class Kaluram {
 public static void main(String[] args) {
	 
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter total rows(odd nums)");
	 int rn = sc.nextInt();
	 System.out.println("Enter total columns(odd nums)");
	 int cn = sc.nextInt();
	
		
		for(int r=1; r<=rn; r++) 
		{
			for(int c=1; c<=cn; c++)
			{
				if(r==(rn/2)+1 && c==(cn/2)+1) 
				{
				  System.out.print("O ");	
				}else if(r==1 || c==1||r==rn||c==cn
						|| r==(rn/2)+1
						||c==(cn/2)+1
						 ) 
				{
					System.out.print("  ");
				}
				else 
				{
					System.out.print("* ");
				}
			}
			System.out.println();
		}	
}
}
