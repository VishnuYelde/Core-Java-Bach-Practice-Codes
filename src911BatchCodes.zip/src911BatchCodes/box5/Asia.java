package box5;

public class Asia {
   public static void main(String[] args) {
	int rn=9;
	int cn=9;
	
	int num=10;
	int re = 90;
	   for(int r=1; r<=rn; r++) 
		{
			for(int c=1; c<=cn; c++)
			{
			   if(r==1 || c==1 || r==rn|| c==cn) {
				   System.out.print("*  ");
				   num++;
			   }else {
				   System.out.print(re+" ");
				   re--;
			   }
			}
			System.out.println();
		}
}
}
