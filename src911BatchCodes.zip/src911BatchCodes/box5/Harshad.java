package box5;

public class Harshad {
   public static void main(String[] args) {
	   
	   int rn = 5;
	   int cn = 5;
	   
	   for(int r=rn; r>=1; r--) 
		  {
			  for(int c=1; c<=5; c++) 
			  {
				  System.out.print(r+" ");
			  }
			  System.out.println();
		  }
}
}
