package box5;

public class Ravi {
  public static void main(String[] args) {
	
	  int rn = 8;
		int cn =8;
		
		for(int r=1; r<=rn; r++) 
		{
			for(int c=1; c<=cn; c++)
			{
				if(c==1 ||c==cn||r==c||r+c==rn+1 ) 
				{
					System.out.print("💖 ");
				}
				else 
				{
					System.out.print("⛷️ ");
				}
			}
			System.out.println();
		}	
}
}
