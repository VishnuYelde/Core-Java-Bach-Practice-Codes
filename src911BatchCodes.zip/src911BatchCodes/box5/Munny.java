package box5;

public class Munny {
  public static void main(String[] args) {
	
	  int rn=5;
	  int cn=5;
	  
	  for(int r=1; r<=rn; r++) 
	  {
		  for(int c=1; c<=cn; c++) 
		  {
			  if(r%2 ==0) {
				  System.out.print("1 ");
			  }else {
				  System.out.print("0 ");
			  }
		  }
		  System.out.println();
	  }

}
}
