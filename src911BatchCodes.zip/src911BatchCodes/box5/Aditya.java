package box5;

public class Aditya {
   public static void main(String[] args) {
	System.out.println("Main start");

	int rn = 7;
	int cn = 7;
	
	for(int r=1; r<=rn; r++) 
	{
		for(int c=1; c<=cn; c++)
		{
			if(r==1 || c==1||r==rn||c==cn
					||r==c
					|| r+c ==rn+1) 
			{
				System.out.print("* ");
			}
			else 
			{
				System.out.print("  ");
			}
		}
		System.out.println();
	}
	
	
	System.out.println("Main End");
	
	
}
}
