package box5;

public class Mari {
  public static void main(String[] args) {
	
	  int rn=10;
	  int cn=10;
	  
	  for(int r=1; r<=rn; r++) 
	  {
		  for(int c=1; c<=cn; c++) 
		  {
			  if((r+c)%2 ==0) {
				  System.out.print("😍 ");
			  }else {
				  System.out.print("💖 ");
			  }
			  try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				return;
			}
		  }
		  System.out.println();
	  }
}
}
