package box5;

public class Bus {
  public static void main(String[] args) {
	  int rn=15;
		int cn=15;
	
		   for(int r=1; r<=rn; r++) 
			{
				for(int c=1; c<=cn; c++)
				{
				   if(   r==c ||
						  (r==1 && c<=(cn/2)+1 )
						   || c==1 && r<=(rn/2)+1
						   || r==rn && c>=(cn/2)+1 
						   || (c==cn && r>=(rn/2)+1)
						   || r==(rn/2)+1 || c==(cn/2)+1) {
					   System.out.print("* ");
				   }else {
					   System.out.print("  ");
				   }
				}
				System.out.println();
			}
}
}
