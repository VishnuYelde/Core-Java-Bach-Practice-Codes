package box12Acc;

import box11Access.Conjuring;

   //diff class diff package
public class Narsimha {
  public static void main(String[] args) {
	System.out.println("Narsimha start");
	
	Conjuring m1 = new Conjuring(); //Object
	System.out.println(m1.a);
//	System.out.println(m1.b);
//	System.out.println(m1.c);
//	System.out.println(m1.d);
	
	m1.demo1();
//	m1.demo2();
//	m1.demo3();
//	m1.demo4();
	
	System.out.println("Narsimha End");
}
}
